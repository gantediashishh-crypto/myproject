# Plant Care Report

Generated: 2026-11-23

| ID | Plant | Category | Location | Last watered | Due | Status |
|---|---|---|---|---|---|---|
| PL-001 | Monstera Deliciosa | indoor | Living room | 2026-11-19 | 2026-11-26 | Healthy |
| PL-002 | Snake Plant | indoor | Bedroom | 2026-11-14 | 2026-11-24 | Due soon |
| PL-003 | Peace Lily | indoor | Study | 2026-11-10 | 2026-11-24 | Due soon |
| PL-004 | Aloe Vera | succulent | Kitchen | 2026-11-21 | 2026-12-12 | Healthy |
| PL-005 | Echeveria | succulent | Windowsill | 2026-11-08 | 2026-12-08 | Healthy |
| PL-006 | Basil | herb | Kitchen | 2026-11-22 | 2026-11-25 | Due soon |
| PL-007 | Rosemary | herb | Balcony | 2026-11-21 | 2026-11-26 | Healthy |
| PL-008 | Rose Bush | flowering | Front garden | 2026-10-11 | 2026-10-29 | Overdue |
| PL-009 | Sunflower | flowering | Back garden | 2026-11-19 | 2026-11-26 | Healthy |
| PL-010 | Tomato Plant | outdoor | Vegetable patch | 2026-11-20 | 2026-11-30 | Healthy |
| PL-011 | Monstera Deliciosa B | indoor | Living room | 2026-11-21 | 2026-12-05 | Healthy |
| PL-012 | Snake Plant B | indoor | Bedroom | 2026-11-08 | 2026-11-29 | Healthy |
| PL-013 | Peace Lily B | indoor | Study | 2026-11-13 | 2026-12-13 | Healthy |
| PL-014 | Aloe Vera B | succulent | Kitchen | 2026-11-22 | 2026-11-25 | Due soon |
| PL-015 | Echeveria B | succulent | Windowsill | 2026-11-22 | 2026-11-27 | Healthy |
| PL-016 | Basil B | herb | Kitchen | 2026-11-21 | 2026-12-09 | Healthy |
| PL-017 | Rosemary B | herb | Balcony | 2026-11-18 | 2026-11-25 | Due soon |
| PL-018 | Rose Bush B | flowering | Front garden | 2026-11-16 | 2026-11-26 | Healthy |
| PL-019 | Sunflower B | flowering | Back garden | 2026-10-17 | 2026-10-31 | Overdue |
| PL-020 | Tomato Plant B | outdoor | Vegetable patch | 2026-11-03 | 2026-11-24 | Due soon |
| PL-021 | Monstera Deliciosa C | indoor | Living room | 2026-11-02 | 2026-12-02 | Healthy |
| PL-022 | Snake Plant C | indoor | Bedroom | 2026-11-22 | 2026-11-25 | Due soon |
| PL-023 | Peace Lily C | indoor | Study | 2026-11-22 | 2026-11-27 | Healthy |
| PL-024 | Aloe Vera C | succulent | Kitchen | 2026-11-06 | 2026-11-24 | Due soon |
| PL-025 | Echeveria C | succulent | Windowsill | 2026-11-22 | 2026-11-29 | Healthy |
| PL-026 | Basil C | herb | Kitchen | 2026-11-22 | 2026-12-02 | Healthy |
| PL-027 | Rosemary C | herb | Balcony | 2026-11-22 | 2026-12-06 | Healthy |
| PL-028 | Rose Bush C | flowering | Front garden | 2026-11-16 | 2026-12-07 | Healthy |
| PL-029 | Sunflower C | flowering | Back garden | 2026-10-25 | 2026-11-24 | Due soon |
| PL-030 | Tomato Plant C | outdoor | Vegetable patch | 2026-11-04 | 2026-11-07 | Overdue |
| PL-031 | Monstera Deliciosa D | indoor | Living room | 2026-11-22 | 2026-11-27 | Healthy |
| PL-032 | Snake Plant D | indoor | Bedroom | 2026-11-08 | 2026-11-26 | Healthy |
| PL-033 | Peace Lily D | indoor | Study | 2026-11-20 | 2026-11-27 | Healthy |
| PL-034 | Aloe Vera D | succulent | Kitchen | 2026-11-15 | 2026-11-25 | Due soon |
| PL-035 | Echeveria D | succulent | Windowsill | 2026-11-13 | 2026-11-27 | Healthy |
| PL-036 | Basil D | herb | Kitchen | 2026-11-16 | 2026-12-07 | Healthy |
| PL-037 | Rosemary D | herb | Balcony | 2026-11-06 | 2026-12-06 | Healthy |
| PL-038 | Rose Bush D | flowering | Front garden | 2026-11-22 | 2026-11-25 | Due soon |
| PL-039 | Sunflower D | flowering | Back garden | 2026-11-20 | 2026-11-25 | Due soon |
| PL-040 | Tomato Plant D | outdoor | Vegetable patch | 2026-11-07 | 2026-11-25 | Due soon |