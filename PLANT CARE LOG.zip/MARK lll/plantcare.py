import csv
import json
import random
import re
from datetime import date, datetime, timedelta
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
PLANTS_JSON = DATA_DIR / "plants.json"
PLANTS_CSV = DATA_DIR / "plants.csv"
IMPORT_ERROR_CSV = DATA_DIR / "import_errors.csv"
CATEGORIES = ("indoor", "outdoor", "succulent", "herb", "flowering")


def validate_login_inputs(email, password):
    email = str(email).strip()
    password = str(password)
    if not re.fullmatch(r"[^@\s]+@gmail\.com", email, flags=re.IGNORECASE):
        raise ValueError("Enter a valid email address ending in @gmail.com.")
    if len(password) < 8 or not password.strip():
        raise ValueError("Password must be at least 8 characters.")
    if len(password) > 128:
        raise ValueError("Password must be 128 characters or fewer.")
    return email.lower()


def parse_iso_date(value):
    if not value:
        raise ValueError("Date cannot be blank.")
    value = str(value).strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("Use date format YYYY-MM-DD.")
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        raise ValueError("Use date format YYYY-MM-DD.")
    if parsed > date.today():
        raise ValueError("Date cannot be in the future.")
    return parsed.isoformat()


def validate_plant(name, category, location, interval, last_watered):
    name = str(name).strip()
    if not name:
        raise ValueError("Plant name cannot be blank.")
    if len(name) > 60:
        raise ValueError("Plant name must be 60 characters or fewer.")
    category = str(category).strip().lower()
    if category not in CATEGORIES:
        raise ValueError("Category must be one of: " + ", ".join(CATEGORIES) + ".")
    location = str(location).strip()
    if not location:
        raise ValueError("Location cannot be blank.")
    if len(location) > 40:
        raise ValueError("Location must be 40 characters or fewer.")
    text = str(interval).strip()
    try:
        if isinstance(interval, float) and not interval.is_integer():
            raise ValueError
        interval = int(text)
    except (TypeError, ValueError):
        raise ValueError("Watering interval must be a whole number.")
    if text not in (str(interval), f"{interval}.0"):
        raise ValueError("Watering interval must be a whole number.")
    if interval < 1 or interval > 60:
        raise ValueError("Watering interval must be from 1 to 60 days.")
    last_watered = parse_iso_date(last_watered)
    return name, category, location, interval, last_watered


def _storage_paths(data_dir=None):
    if data_dir is None:
        return DATA_DIR, PLANTS_JSON, PLANTS_CSV
    root = Path(data_dir)
    return root, root / "plants.json", root / "plants.csv"


def ensure_storage(data_dir=None):
    storage_dir, plants_json, plants_csv = _storage_paths(data_dir)
    storage_dir.mkdir(parents=True, exist_ok=True)
    if not plants_json.exists():
        sample = create_sample_data()
        plants_json.write_text(json.dumps(sample, indent=2), encoding="utf-8")
        export_csv(sample["plants"], plants_csv)
    elif plants_json.stat().st_size == 0:
        sample = create_sample_data()
        plants_json.write_text(json.dumps(sample, indent=2), encoding="utf-8")
        export_csv(sample["plants"], plants_csv)


def load_plants(data_dir=None):
    ensure_storage(data_dir)
    _, plants_json, plants_csv = _storage_paths(data_dir)
    try:
        data = json.loads(plants_json.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or "plants" not in data:
            raise ValueError("Invalid root object")
        if not isinstance(data["plants"], list):
            raise ValueError("Plants must be a list")
        if not isinstance(data.get("watering_history", []), list):
            raise ValueError("Watering history must be a list")
        data.setdefault("watering_history", [])
        plant_ids = set()
        for plant in data["plants"]:
            if not isinstance(plant, dict):
                raise ValueError("Plant records must be objects.")
            if not all(key in plant for key in ("id", "name", "category", "location",
                                                "watering_interval", "last_watered")):
                raise ValueError("A plant record is missing required fields.")
            plant_id = str(plant["id"]).strip()
            if not plant_id or plant_id in plant_ids:
                raise ValueError("Plant IDs must be present and unique.")
            if not isinstance(plant["name"], str) or not isinstance(plant["location"], str):
                raise ValueError("Plant names and locations must be text.")
            name, category, location, interval, last_watered = validate_plant(
                plant["name"],
                plant["category"],
                plant["location"],
                plant["watering_interval"],
                plant["last_watered"],
            )
            plant.update({
                "id": plant_id,
                "name": name,
                "category": category,
                "location": location,
                "watering_interval": interval,
                "last_watered": last_watered,
                "notes": str(plant.get("notes", "")).strip(),
            })
            plant_ids.add(plant_id)
        for event in data["watering_history"]:
            if (
                not isinstance(event, dict)
                or not isinstance(event.get("plant_id"), str)
                or event["plant_id"] not in plant_ids
            ):
                raise ValueError("Watering history contains an invalid plant reference.")
            event["date"] = parse_iso_date(event.get("date"))
            event["note"] = str(event.get("note", "")).strip()
        if not plants_csv.exists() or plants_csv.stat().st_size < 100:
            export_csv(data["plants"], plants_csv)
        return data
    except (json.JSONDecodeError, OSError, ValueError):
        clean = {"plants": create_sample_data()["plants"], "watering_history": []}
        _save_for_directory(clean, data_dir)
        return clean


def save_data(data, data_dir=None):
    storage_dir, plants_json, plants_csv = _storage_paths(data_dir)
    storage_dir.mkdir(parents=True, exist_ok=True)
    plants_json.write_text(json.dumps(data, indent=2), encoding="utf-8")
    export_csv(data["plants"], plants_csv)


def _save_for_directory(data, data_dir=None):
    if data_dir is None:
        save_data(data)
    else:
        save_data(data, data_dir)


def next_id(plants):
    used = {int(p["id"].replace("PL-", "")) for p in plants if str(p["id"]).startswith("PL-")}
    number = 1
    while number in used:
        number += 1
    return f"PL-{number:03d}"


def add_plant(data, name, category, location, interval, last_watered, notes="", data_dir=None):
    name, category, location, interval, last_watered = validate_plant(
        name, category, location, interval, last_watered
    )
    plant = {
        "id": next_id(data["plants"]),
        "name": name,
        "category": category,
        "location": location,
        "watering_interval": interval,
        "last_watered": last_watered,
        "notes": str(notes).strip(),
    }
    data["plants"].append(plant)
    _save_for_directory(data, data_dir)
    return plant


def update_plant(data, plant_id, name, category, location, interval, last_watered, notes,
                 data_dir=None):
    name, category, location, interval, last_watered = validate_plant(
        name, category, location, interval, last_watered
    )
    for plant in data["plants"]:
        if plant["id"] == plant_id:
            plant.update({
                "name": name,
                "category": category,
                "location": location,
                "watering_interval": interval,
                "last_watered": last_watered,
                "notes": str(notes).strip(),
            })
            _save_for_directory(data, data_dir)
            return plant
    raise ValueError("Plant not found.")


def log_watering(data, plant_id, watered_date, note="", data_dir=None):
    watered_date = parse_iso_date(watered_date)
    plant = find_plant(data, plant_id)
    if plant is None:
        raise ValueError("Plant not found.")
    old = plant["last_watered"]
    if watered_date < old:
        raise ValueError("Watering date cannot be earlier than the recorded last-watered date.")
    plant["last_watered"] = watered_date
    data["watering_history"].append({
        "plant_id": plant_id,
        "date": watered_date,
        "note": str(note).strip(),
    })
    _save_for_directory(data, data_dir)


def find_plant(data, plant_id):
    return next((p for p in data["plants"] if p["id"] == plant_id), None)


def plant_status(plant, today=None):
    today = today or date.today()
    last = datetime.strptime(plant["last_watered"], "%Y-%m-%d").date()
    days_since = (today - last).days
    due = last + timedelta(days=int(plant["watering_interval"]))
    overdue_days = (today - due).days
    if overdue_days > 0:
        status = "Overdue"
    elif overdue_days >= -2:
        status = "Due soon"
    else:
        status = "Healthy"
    return {
        "days_since": days_since,
        "next_due": due.isoformat(),
        "overdue_days": overdue_days,
        "status": status,
    }


def filter_plants(data, keyword="", category="All", location="All", status="All"):
    keyword = keyword.strip().lower()
    results = []
    for plant in data["plants"]:
        text = f"{plant['name']} {plant['notes']}".lower()
        if keyword and keyword not in text:
            continue
        if category != "All" and plant["category"] != category:
            continue
        if location != "All" and plant["location"] != location:
            continue
        if status != "All" and plant_status(plant)["status"] != status:
            continue
        results.append(plant)
    return results


def summary_report(data):
    plants = data["plants"]
    category_counts = {c: sum(p["category"] == c for p in plants) for c in CATEGORIES}
    overdue = [p for p in plants if plant_status(p)["status"] == "Overdue"]
    average = round(sum(int(p["watering_interval"]) for p in plants) / len(plants), 1) if plants else 0
    neglected = max(plants, key=lambda p: plant_status(p)["days_since"]) if plants else None
    cutoff = date.today() - timedelta(days=30)
    recent = sum(
        datetime.strptime(h["date"], "%Y-%m-%d").date() >= cutoff
        for h in data["watering_history"]
    )
    return {
        "total": len(plants),
        "categories": category_counts,
        "overdue_count": len(overdue),
        "average_interval": average,
        "most_neglected": neglected,
        "recent_waterings": recent,
    }


def export_csv(plants, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id", "name", "category", "location", "watering_interval", "last_watered", "notes"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for plant in plants:
            writer.writerow({field: plant.get(field, "") for field in fields})
    return str(path)


def export_markdown(data, path):
    lines = ["# Plant Care Report", "", f"Generated: {date.today().isoformat()}", ""]
    lines += ["| ID | Plant | Category | Location | Last watered | Due | Status |", "|---|---|---|---|---|---|---|"]
    for plant in data["plants"]:
        status = plant_status(plant)
        lines.append(
            f"| {plant['id']} | {plant['name']} | {plant['category']} | {plant['location']} "
            f"| {plant['last_watered']} | {status['next_due']} | {status['status']} |"
        )
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def import_csv(path, data, data_dir=None):
    accepted = 0
    errors = []
    with open(path, "r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        headers = {
            field.strip().lower(): field
            for field in (reader.fieldnames or [])
            if field and field.strip()
        }
        required = ("name", "category", "location", "watering_interval", "last_watered")
        missing = [field for field in required if field not in headers]
        if missing:
            raise ValueError("CSV is missing required columns: " + ", ".join(missing) + ".")
        for row_number, row in enumerate(reader, start=2):
            original_row = row
            row = {
                field: row.get(original)
                for field, original in headers.items()
            }
            try:
                name, category, location, interval, last_watered = validate_plant(
                    row.get("name"),
                    row.get("category"),
                    row.get("location"),
                    row.get("watering_interval"),
                    row.get("last_watered"),
                )
                data["plants"].append({
                    "id": next_id(data["plants"]),
                    "name": name,
                    "category": category,
                    "location": location,
                    "watering_interval": interval,
                    "last_watered": last_watered,
                    "notes": str(row.get("notes", "")).strip(),
                })
                accepted += 1
            except (ValueError, KeyError) as exc:
                errors.append({"row": row_number, "error": str(exc), "data": json.dumps(original_row)})
    if accepted:
        _save_for_directory(data, data_dir)
    if errors:
        error_path = IMPORT_ERROR_CSV if data_dir is None else Path(data_dir) / "import_errors.csv"
        with error_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["row", "error", "data"])
            writer.writeheader()
            writer.writerows(errors)
    return accepted, errors


def create_sample_data():
    rng = random.Random(11)
    today = date.today()
    names = [
        ("Monstera Deliciosa", "indoor", "Living room"), ("Snake Plant", "indoor", "Bedroom"),
        ("Peace Lily", "indoor", "Study"), ("Aloe Vera", "succulent", "Kitchen"),
        ("Echeveria", "succulent", "Windowsill"), ("Basil", "herb", "Kitchen"),
        ("Rosemary", "herb", "Balcony"), ("Rose Bush", "flowering", "Front garden"),
        ("Sunflower", "flowering", "Back garden"), ("Tomato Plant", "outdoor", "Vegetable patch"),
    ]
    plants = []
    history = []
    for i in range(40):
        name, category, location = names[i % len(names)]
        suffix = "" if i < len(names) else f" {chr(65 + i // len(names))}"
        interval = [7, 10, 14, 21, 30, 3, 5, 18][i % 8]
        if i in (7, 18, 29):
            days = interval + rng.randint(8, 25)
        elif i in (3, 24):
            days = rng.randint(0, 2)
        else:
            days = rng.randint(0, max(1, interval - 2))
        last = (today - timedelta(days=days)).isoformat()
        plant_id = f"PL-{i + 1:03d}"
        plants.append({
            "id": plant_id,
            "name": name + suffix,
            "category": category,
            "location": location,
            "watering_interval": interval,
            "last_watered": last,
            "notes": ["Rotate monthly", "Keep away from direct sun", "Trim yellow leaves", "Mist in dry weather", "Check soil before watering"][i % 5],
        })
        for offset in (7, 14, 21):
            if i % 3 == 0:
                watered = today - timedelta(days=offset)
                if watered.isoformat() >= last:
                    history.append({"plant_id": plant_id, "date": watered.isoformat(), "note": "Routine watering"})
    return {"plants": plants, "watering_history": history}
