import hashlib
import hmac
import re
import secrets
import sqlite3
import uuid
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from plantcare import DATA_DIR, validate_login_inputs


ACCOUNT_DB = DATA_DIR / "accounts.sqlite3"
USER_DATA_ROOT = DATA_DIR / "users"
PASSWORD_HASH_ITERATIONS = 600_000
_USER_ID_PATTERN = re.compile(r"[a-f0-9]{32}")


def initialize_auth_store():
    ACCOUNT_DB.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(ACCOUNT_DB, timeout=30)) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                user_id TEXT PRIMARY KEY,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                salt BLOB NOT NULL,
                password_hash BLOB NOT NULL,
                iterations INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        connection.commit()


def _password_hash(password, salt, iterations):
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations,
        dklen=32,
    )


def create_account(email, password):
    email = validate_login_inputs(email, password)
    user_id = uuid.uuid4().hex
    salt = secrets.token_bytes(16)
    password_hash = _password_hash(password, salt, PASSWORD_HASH_ITERATIONS)
    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    initialize_auth_store()
    with closing(sqlite3.connect(ACCOUNT_DB, timeout=30)) as connection:
        try:
            connection.execute(
                """
                INSERT INTO accounts (
                    user_id, email, salt, password_hash, iterations, created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    email,
                    salt,
                    password_hash,
                    PASSWORD_HASH_ITERATIONS,
                    created_at,
                ),
            )
            connection.commit()
        except sqlite3.IntegrityError as exc:
            raise ValueError("An account with this email already exists. Sign in instead.") from exc
    return {"user_id": user_id, "email": email}


def authenticate_account(email, password):
    email = validate_login_inputs(email, password)
    initialize_auth_store()
    with closing(sqlite3.connect(ACCOUNT_DB, timeout=30)) as connection:
        row = connection.execute(
            """
            SELECT user_id, email, salt, password_hash, iterations
            FROM accounts
            WHERE email = ? COLLATE NOCASE
            """,
            (email,),
        ).fetchone()

    if row is None:
        raise ValueError("Email or password is incorrect.")
    user_id, stored_email, salt, expected_hash, iterations = row
    supplied_hash = _password_hash(password, salt, iterations)
    if not hmac.compare_digest(supplied_hash, expected_hash):
        raise ValueError("Email or password is incorrect.")
    return {"user_id": user_id, "email": stored_email}


def get_account(user_id):
    if not isinstance(user_id, str) or not _USER_ID_PATTERN.fullmatch(user_id):
        return None
    initialize_auth_store()
    with closing(sqlite3.connect(ACCOUNT_DB, timeout=30)) as connection:
        row = connection.execute(
            "SELECT user_id, email FROM accounts WHERE user_id = ?",
            (user_id,),
        ).fetchone()
    if row is None:
        return None
    return {"user_id": row[0], "email": row[1]}


def user_data_directory(user_id):
    if not isinstance(user_id, str) or not _USER_ID_PATTERN.fullmatch(user_id):
        raise ValueError("Invalid account identifier.")
    path = USER_DATA_ROOT / user_id
    path.mkdir(parents=True, exist_ok=True)
    return path
