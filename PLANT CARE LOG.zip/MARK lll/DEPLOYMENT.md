# Browser deployment

The app runs locally in a browser or on a Python web host.

Local:

```powershell
python -m streamlit run app.py
```

The landing page supports account creation and sign-in. Account emails and salted
password hashes are stored in `data/accounts.sqlite3`. Website plant records,
imports, and reports are stored in per-account folders under `data/users/`.

For Streamlit Community Cloud or another web host, select `app.py` as the entry
point and install `requirements.txt`. Configure a persistent writable volume for
the entire `data/` directory before relying on hosted accounts or long-term
records. Ephemeral storage can erase accounts and plant data on restart or redeploy.

Before public use, configure HTTPS, persistent backups, request throttling, and an
account recovery process. The local account system does not provide email
verification, password reset, or multi-factor authentication. Review the privacy
and terms pages for your hosting setup.

To use a custom domain, configure it with the chosen host, enable HTTPS, and add the
DNS records supplied by that host. No domain or hosting account has been supplied or
configured in this project.
