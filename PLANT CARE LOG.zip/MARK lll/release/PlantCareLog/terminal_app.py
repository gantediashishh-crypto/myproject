import csv
from datetime import date

from plantcare import (
    CATEGORIES,
    add_plant,
    export_csv,
    export_markdown,
    filter_plants,
    import_csv,
    load_plants,
    log_watering,
    plant_status,
    summary_report,
)


def input_text(prompt, allow_blank=False):
    while True:
        value = input(prompt).strip()
        if value or allow_blank:
            return value
        print("Invalid: a value is required.")


def input_interval():
    while True:
        value = input("Watering interval (1-60 days): ").strip()
        try:
            interval = int(value)
            if str(interval) != value:
                raise ValueError
            if interval < 1 or interval > 60:
                raise ValueError
            return interval
        except ValueError:
            print("Invalid: enter a whole number from 1 to 60.")


def input_date(prompt):
    while True:
        value = input(prompt).strip()
        try:
            parsed = date.fromisoformat(value)
            if parsed > date.today():
                raise ValueError
            return value
        except ValueError:
            print("Invalid: use YYYY-MM-DD and do not use a future date.")


def print_plants(plants):
    if not plants:
        print("No plants found.")
        return
    print(f"{'ID':<8} {'Name':<28} {'Category':<11} {'Location':<18} {'Last watered':<12} {'Status'}")
    print("-" * 100)
    for plant in plants:
        status = plant_status(plant)
        print(f"{plant['id']:<8} {plant['name']:<28} {plant['category']:<11} "
              f"{plant['location']:<18} {plant['last_watered']:<12} {status['status']}")


def main():
    data = load_plants()
    menu = [
        "Add a plant",
        "Log a watering",
        "Add or edit a care note",
        "View all plants",
        "Search and filter",
        "Overdue alerts",
        "Summary report",
        "Charts",
        "Export report",
        "Import CSV",
        "Exit",
    ]
    while True:
        print("\nPLANT CARE LOG")
        for number, label in enumerate(menu, 1):
            print(f"{number}. {label}")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            while True:
                try:
                    name = input_text("Plant name: ")
                    category = input("Category (indoor/outdoor/succulent/herb/flowering): ").strip().lower()
                    location = input_text("Location: ")
                    interval = input_interval()
                    last = input_date("Last watered (YYYY-MM-DD): ")
                    notes = input_text("Care note (optional): ", allow_blank=True)
                    plant = add_plant(data, name, category, location, interval, last, notes)
                    print(f"Added {plant['name']} ({plant['id']}).")
                    break
                except ValueError as exc:
                    print(f"Invalid: {exc}")
        elif choice == "2":
            print_plants(data["plants"])
            plant_id = input_text("Plant ID: ").upper()
            watered = input_date("Watering date (YYYY-MM-DD): ")
            note = input_text("Note (optional): ", allow_blank=True)
            try:
                log_watering(data, plant_id, watered, note)
                print("Watering logged.")
            except ValueError as exc:
                print(f"Invalid: {exc}")
        elif choice == "3":
            print_plants(data["plants"])
            plant_id = input_text("Plant ID: ").upper()
            plant = next((p for p in data["plants"] if p["id"] == plant_id), None)
            if not plant:
                print("Plant not found.")
            else:
                print("Current note:", plant["notes"] or "(none)")
                plant["notes"] = input_text("New care note (blank to clear): ", allow_blank=True)
                from plantcare import save_data
                save_data(data)
                print("Care note saved.")
        elif choice == "4":
            print_plants(data["plants"])
        elif choice == "5":
            keyword = input("Keyword (name or note): ").strip()
            category = input("Category (or All): ").strip().lower()
            if not category:
                category = "All"
            print_plants(filter_plants(data, keyword, category if category in CATEGORIES or category == "All" else "All"))
        elif choice == "6":
            overdue = [p for p in data["plants"] if plant_status(p)["status"] == "Overdue"]
            due = [p for p in data["plants"] if plant_status(p)["status"] == "Due soon"]
            print("\nOVERDUE")
            print_plants(overdue)
            print("\nDUE SOON")
            print_plants(due)
        elif choice == "7":
            report = summary_report(data)
            print(f"\nTotal plants: {report['total']}")
            print("Plants per category:")
            for category, count in report["categories"].items():
                print(f"  {category}: {count}")
            print(f"Overdue: {report['overdue_count']}")
            print(f"Average watering interval: {report['average_interval']} days")
            if report["most_neglected"]:
                p = report["most_neglected"]
                print(f"Most neglected: {p['name']} ({plant_status(p)['days_since']} days)")
            print(f"Waterings in last 30 days: {report['recent_waterings']}")
        elif choice == "8":
            try:
                import matplotlib.pyplot as plt
            except ImportError:
                print("Matplotlib is not installed.")
                continue
            print("1. Watering count per plant")
            print("2. Plants per category")
            print("3. Waterings over time")
            chart_choice = input("Choose chart: ").strip()
            fig, ax = plt.subplots(figsize=(9, 5))
            if chart_choice == "2":
                counts = {category: sum(p["category"] == category for p in data["plants"]) for category in CATEGORIES}
                ax.bar([category.title() for category in counts], list(counts.values()), color="#5E7A65")
                ax.set_ylabel("Plants")
                ax.set_title("Plants per category")
            elif chart_choice == "3":
                daily = {}
                for item in data["watering_history"]:
                    daily[item["date"]] = daily.get(item["date"], 0) + 1
                dates = sorted(daily)
                ax.plot(dates, [daily[item] for item in dates], color="#5E7A65", marker="o")
                ax.set_ylabel("Waterings")
                ax.set_title("Waterings over time")
                fig.autofmt_xdate()
            else:
                counts = {p["name"]: sum(h["plant_id"] == p["id"] for h in data["watering_history"]) for p in data["plants"]}
                labels = list(counts)[-12:]
                ax.barh(labels, [counts[label] for label in labels], color="#5E7A65")
                ax.invert_yaxis()
                ax.set_xlabel("Waterings")
                ax.set_title("Watering count per plant")
            ax.spines[["top", "right"]].set_visible(False)
            fig.tight_layout()
            plt.show()
        elif choice == "9":
            with open("data/plant-care-export.txt", "w", encoding="utf-8") as handle:
                handle.write("Plant Care Report\n")
                for plant in data["plants"]:
                    status = plant_status(plant)
                    handle.write(f"{plant['id']} | {plant['name']} | {status['status']} | due {status['next_due']}\n")
            export_csv(data["plants"], "data/plant-care-export.csv")
            export_markdown(data, "data/plant-care-export.md")
            print("Exported TXT, CSV, and Markdown reports to the data folder.")
        elif choice == "10":
            path = input("CSV file path: ").strip()
            try:
                accepted, errors = import_csv(path, data)
                print(f"Imported {accepted} records; {len(errors)} invalid rows.")
            except (OSError, csv.Error) as exc:
                print(f"Could not import file: {exc}")
        elif choice == "11":
            print("Goodbye.")
            break
        else:
            print("Invalid menu choice.")


if __name__ == "__main__":
    main()
