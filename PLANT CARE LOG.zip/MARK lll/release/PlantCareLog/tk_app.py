import tkinter as tk
from datetime import date
from tkinter import messagebox, ttk

from plantcare import CATEGORIES, add_plant, load_plants, log_watering, plant_status


class PlantCareApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Plant Care Log")
        self.geometry("760x520")
        self.configure(bg="#FFFFFF")
        self.data = load_plants()
        ttk.Style().configure("TFrame", background="#FFFFFF")

        ttk.Label(self, text="Plant Care Log", font=("Segoe UI", 18, "bold")).pack(pady=(16, 8))
        form = ttk.Frame(self)
        form.pack(padx=24, pady=8, fill="x")

        labels = ["Plant name", "Category", "Location", "Interval (days)", "Last watered"]
        self.entries = []
        for index, label in enumerate(labels):
            ttk.Label(form, text=label).grid(row=index, column=0, sticky="w", pady=5)
            if index == 1:
                value = ttk.Combobox(form, values=CATEGORIES, state="readonly")
            elif index == 3:
                value = ttk.Spinbox(form, from_=1, to=60)
            else:
                value = ttk.Entry(form)
            value.grid(row=index, column=1, sticky="ew", pady=5)
            self.entries.append(value)
        self.entries[1].set(CATEGORIES[0])
        self.entries[3].set("7")
        self.entries[4].insert(0, date.today().isoformat())
        form.columnconfigure(1, weight=1)

        ttk.Button(form, text="Save plant", command=self.save).grid(row=5, column=1, sticky="e", pady=12)
        ttk.Button(form, text="Log watering", command=self.log_watering).grid(row=5, column=0, sticky="w", pady=12)
        ttk.Label(self, text="Plant records", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=24)

        columns = ("id", "name", "category", "location", "status")
        self.table = ttk.Treeview(self, columns=columns, show="headings", height=10)
        for column in columns:
            self.table.heading(column, text=column.title())
            self.table.column(column, width=130)
        self.table.pack(fill="both", expand=True, padx=24, pady=(4, 16))
        self.refresh()

    def save(self):
        name, category, location, interval, last = [v.get() for v in self.entries]
        try:
            add_plant(self.data, name, category, location, interval, last)
            self.refresh()
            messagebox.showinfo("Saved", "Plant record added.")
        except ValueError as exc:
            messagebox.showerror("Invalid input", str(exc))

    def log_watering(self):
        selected = self.table.selection()
        if not selected:
            messagebox.showerror("No plant selected", "Select a plant in the table first.")
            return
        plant_id = self.table.item(selected[0], "values")[0]
        try:
            log_watering(self.data, plant_id, date.today().isoformat(), "Watered in Tkinter")
            self.refresh()
            messagebox.showinfo("Saved", "Watering logged for today.")
        except ValueError as exc:
            messagebox.showerror("Invalid input", str(exc))

    def refresh(self):
        for item in self.table.get_children():
            self.table.delete(item)
        for plant in self.data["plants"]:
            status = plant_status(plant)["status"]
            self.table.insert("", "end", values=(plant["id"], plant["name"], plant["category"],
                                                  plant["location"], status))


if __name__ == "__main__":
    PlantCareApp().mainloop()
