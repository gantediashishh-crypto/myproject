import sqlite3

import pytest

import auth


def test_account_creation_authentication_and_password_hashing(monkeypatch, tmp_path):
    database_path = tmp_path / "accounts.sqlite3"
    monkeypatch.setattr(auth, "ACCOUNT_DB", database_path)
    monkeypatch.setattr(auth, "PASSWORD_HASH_ITERATIONS", 1_000)

    account = auth.create_account("Plant.Owner@gmail.com", "SecureGarden123")

    assert account["email"] == "plant.owner@gmail.com"
    assert auth.authenticate_account("plant.owner@gmail.com", "SecureGarden123") == account
    assert auth.get_account(account["user_id"]) == account

    with sqlite3.connect(database_path) as connection:
        stored_email, stored_salt, stored_hash = connection.execute(
            "SELECT email, salt, password_hash FROM accounts"
        ).fetchone()
    assert stored_email == account["email"]
    assert len(stored_salt) == 16
    assert stored_hash != b"SecureGarden123"

    with pytest.raises(ValueError, match="Email or password is incorrect"):
        auth.authenticate_account("plant.owner@gmail.com", "WrongGarden123")

    with pytest.raises(ValueError, match="already exists"):
        auth.create_account("PLANT.OWNER@gmail.com", "AnotherGarden123")


def test_account_data_directory_rejects_untrusted_identifiers():
    with pytest.raises(ValueError, match="Invalid account identifier"):
        auth.user_data_directory("../other-account")
