import csv
import json
import tempfile
from datetime import date, timedelta
from pathlib import Path

import plantcare
from plantcare import (
    add_plant,
    filter_plants,
    import_csv,
    log_watering,
    plant_status,
    summary_report,
    validate_plant,
    validate_login_inputs,
)


def test_login_requires_gmail_and_minimum_password_length():
    assert validate_login_inputs("Plant.User+garden@GMAIL.com", "garden123") == "plant.user+garden@gmail.com"
    invalid_cases = [
        ("person@example.com", "garden123"),
        ("person@gmail.com.evil.test", "garden123"),
        ("person@gmail.com", "short7"),
        ("person@gmail.com", "        "),
    ]
    for email, password in invalid_cases:
        try:
            validate_login_inputs(email, password)
        except ValueError:
            continue
        raise AssertionError(f"Invalid login inputs were accepted: {email!r}")


def test_validation_rejects_blank_name_and_bad_values():
    invalid_cases = [
        ("", "indoor", "Room", 7, date.today().isoformat()),
        ("Rose", "invalid", "Room", 7, date.today().isoformat()),
        ("Rose", "indoor", "", 7, date.today().isoformat()),
        ("Rose", "indoor", "Room", 0, date.today().isoformat()),
        ("Rose", "indoor", "Room", 61, date.today().isoformat()),
        ("Rose", "indoor", "Room", 7.5, date.today().isoformat()),
        ("Rose", "indoor", "Room", 7, (date.today() + timedelta(days=1)).isoformat()),
        ("Rose", "indoor", "Room", 7, "2026-1-2"),
    ]
    for case in invalid_cases:
        try:
            validate_plant(*case)
        except ValueError:
            continue
        raise AssertionError(f"Invalid case was accepted: {case}")


def test_add_log_filter_and_summary(monkeypatch):
    monkeypatch.setattr("plantcare.save_data", lambda data: None)
    data = {"plants": [], "watering_history": []}
    plant = add_plant(
        data,
        "Test Fern",
        "indoor",
        "Office",
        7,
        (date.today() - timedelta(days=10)).isoformat(),
        "Keep humid",
    )
    assert plant_status(plant)["status"] == "Overdue"
    assert filter_plants(data, "fern", "indoor", "Office", "Overdue")

    log_watering(data, plant["id"], date.today().isoformat(), "Routine")
    assert data["watering_history"][0]["plant_id"] == plant["id"]
    report = summary_report(data)
    assert report["total"] == 1
    assert report["overdue_count"] == 0
    assert report["recent_waterings"] == 1


def test_bulk_import_logs_valid_and_invalid_rows(monkeypatch):
    saves = []
    monkeypatch.setattr("plantcare.save_data", lambda data: saves.append(len(data["plants"])))
    data = {"plants": [], "watering_history": []}
    with tempfile.TemporaryDirectory() as directory:
        monkeypatch.setattr("plantcare.IMPORT_ERROR_CSV", Path(directory) / "import_errors.csv")
        path = Path(directory) / "plants.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=["name", "category", "location", "watering_interval", "last_watered", "notes"],
            )
            writer.writeheader()
            writer.writerow({
                "name": "Imported Herb",
                "category": "herb",
                "location": "Kitchen",
                "watering_interval": "5",
                "last_watered": date.today().isoformat(),
                "notes": "Test",
            })
            writer.writerow({
                "name": "",
                "category": "herb",
                "location": "Kitchen",
                "watering_interval": "5",
                "last_watered": date.today().isoformat(),
                "notes": "",
            })
        accepted, errors = import_csv(path, data)
        assert accepted == 1
        assert len(errors) == 1
        assert saves == [1]
        path.write_text("plant\nRose\n", encoding="utf-8")
        try:
            import_csv(path, data)
        except ValueError as exc:
            assert "missing required columns" in str(exc)
        else:
            raise AssertionError("CSV without required headers was accepted.")


def test_semantically_corrupt_json_is_replaced_with_clean_sample_data(monkeypatch, tmp_path):
    plants_json = tmp_path / "plants.json"
    plants_json.write_text(
        json.dumps({
            "plants": [{
                "id": "PL-001",
                "name": None,
                "category": "indoor",
                "location": "Room",
                "watering_interval": 7,
                "last_watered": date.today().isoformat(),
            }],
            "watering_history": [],
        }),
        encoding="utf-8",
    )
    monkeypatch.setattr(plantcare, "DATA_DIR", tmp_path)
    monkeypatch.setattr(plantcare, "PLANTS_JSON", plants_json)
    monkeypatch.setattr(plantcare, "PLANTS_CSV", tmp_path / "plants.csv")

    data = plantcare.load_plants()

    assert len(data["plants"]) == 40
    assert data["plants"][0]["name"]


def test_account_data_directories_keep_plants_separate(tmp_path):
    first_directory = tmp_path / "users" / "first"
    second_directory = tmp_path / "users" / "second"
    first_account_data = plantcare.load_plants(first_directory)
    second_account_data = plantcare.load_plants(second_directory)

    plantcare.add_plant(
        first_account_data,
        "Private Fern",
        "indoor",
        "Study",
        7,
        date.today().isoformat(),
        data_dir=first_directory,
    )

    assert len(plantcare.load_plants(first_directory)["plants"]) == 41
    assert len(plantcare.load_plants(second_directory)["plants"]) == 40
    assert all(
        plant["name"] != "Private Fern"
        for plant in plantcare.load_plants(second_directory)["plants"]
    )
