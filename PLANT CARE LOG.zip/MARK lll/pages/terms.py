from datetime import date

import streamlit as st


st.set_page_config(
    page_title="Terms and Conditions | Plant Care Log",
    page_icon="assets/logo-square.jpg",
    layout="wide",
)

st.markdown(
    """
    <style>
    .stApp { background: #FFFFFF; color: #22252A; }
    header[data-testid="stHeader"] { background: #FFFFFF; }
    [data-testid="stAppDeployButton"] { display: none !important; }
    [data-testid="stStatusWidget"], footer { visibility: hidden; }
    section[data-testid="stSidebar"] { display: none !important; }
    .block-container {
      max-width: 900px;
      padding-top: 1.5rem;
      padding-bottom: 3rem;
    }
    h1 { font-size: 28px !important; line-height: 1.2 !important; }
    h2 { font-size: 18px !important; line-height: 1.35 !important; }
    .st-key-terms_content {
      border-color: #E3E6E4;
      border-radius: 8px;
      padding: 24px;
    }
    .terms-intro { color: #646D75; line-height: 1.6; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.page_link("app.py", label="Plant Care Log")
st.title("Terms and conditions")
st.caption(f"Last updated: {date.today():%d %B %Y}")
st.markdown(
    "These terms explain the current Plant Care Log service and your responsibilities "
    "when using it."
)

with st.container(key="terms_content", border=True):
    st.markdown(
        """
### 1. Accepting these terms
By accessing or using Plant Care Log, you agree to these terms. If you do not agree,
do not use the application.

### 2. What the service provides
Plant Care Log helps organize plant records, watering history, care notes, reminders,
charts, and exports. It is a planning tool; it does not monitor plants or automatically
verify that a plant has been watered.

### 3. Sign-in and access
You may create an account with a `@gmail.com` address and a password from 8 to 128
characters. The application stores a salted password hash, not the raw password.
Email verification, password reset, and multi-factor authentication are not available.
Use a unique password and keep it private. Do not attempt to access another user's account.

### 4. Your records, imports, and exports
You are responsible for the accuracy and appropriateness of the plant information you
enter. Only import CSV files that you are authorized to use. Invalid import rows may be
skipped and recorded in an import error file, so review the results before relying on
them. Check exported files before sharing them.

Website plant records are stored in JSON and CSV files in a separate account folder on
the device or server running the app. Keep your own backups. Hosting, redeployment, or
removal of those files may affect availability or permanently remove records.

### 5. Plant-care information
Watering dates, status labels, and reminders are calculated from the information you
provide. They are estimates, not professional horticultural advice or a guarantee of
plant health. Plant needs vary with species, season, soil, container, and environment.
Check reliable, plant-specific guidance and use your judgment.

### 6. Appropriate use and availability
Use the application lawfully and do not disrupt its operation or upload files that
contain harmful or unauthorized content. The application may change or become
temporarily unavailable. Keep independent copies of records that are important to you.

### 7. Disclaimers and liability
To the extent permitted by applicable law, Plant Care Log is provided as available,
without a guarantee that it will be uninterrupted, error-free, or suitable for every
purpose. Nothing in these terms limits rights or remedies that cannot legally be
limited. To the extent permitted by law, the service operator is not responsible for
indirect losses arising from reliance on reminders, data loss, or inability to use the
service.

### 8. Changes to these terms
These terms may be updated when the application or its operation changes. The date at
the top indicates when this page was last updated. Continued use after an update means
you accept the revised terms.
"""
    )

st.info(
    "Before public or commercial use, have these general terms reviewed and add the "
    "service operator's contact details and applicable governing law."
)
