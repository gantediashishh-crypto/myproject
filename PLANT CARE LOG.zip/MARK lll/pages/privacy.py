import streamlit as st


st.set_page_config(
    page_title="Privacy Policy | Plant Care Log",
    page_icon="assets/logo-square.jpg",
    layout="wide",
)

st.markdown(
    """
    <style>
    .stApp { background: #FFFFFF; color: #22252A; }
    header[data-testid="stHeader"] { background: #FFFFFF; }
    [data-testid="stAppDeployButton"] { display: none !important; }
    [data-testid="stStatusWidget"], footer { visibility: hidden; }
    section[data-testid="stSidebar"] { display: none !important; }
    .block-container {
      max-width: 900px;
      padding-top: 1.5rem;
      padding-bottom: 3rem;
    }
    h1 { font-size: 28px !important; line-height: 1.2 !important; }
    .st-key-privacy_content {
      border-color: #E3E6E4;
      border-radius: 8px;
      padding: 24px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.page_link("app.py", label="Plant Care Log")
st.title("Privacy policy")
st.caption("How account details and plant records are handled.")

with st.container(key="privacy_content", border=True):
    st.markdown(
        """
Plant Care Log stores account emails and salted password hashes in a local SQLite
database at `data/accounts.sqlite3`. Raw passwords are not stored. Use a unique
password. The app does not currently support email verification, password reset, or
account deletion.

Website plant records are stored in JSON and CSV files in a separate folder for each
account under `data/users/`. CSV uploads, import error logs, and generated reports may
also be stored in that account folder. The app operator and hosting provider may be
able to access files on the server. Keep your own backups and do not enter sensitive
personal information.

The sign-in email is limited to Gmail addresses. Plant Care Log does not request
payment or location-tracking details. Data retention depends on the device or hosting
provider; an ephemeral deployment may lose local files when it restarts or is
redeployed.
"""
    )
