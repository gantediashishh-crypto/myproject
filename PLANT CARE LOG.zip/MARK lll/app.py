import csv
import io
import base64
from datetime import date
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from auth import (
    authenticate_account,
    create_account,
    get_account,
    user_data_directory,
)
from plantcare import (
    CATEGORIES,
    add_plant,
    export_markdown,
    filter_plants,
    import_csv,
    load_plants,
    log_watering,
    plant_status,
    summary_report,
    update_plant,
)


st.set_page_config(
    page_title="Plant Care Log",
    page_icon="assets/logo-square.jpg",
    layout="wide",
    initial_sidebar_state="expanded",
)


st.markdown("""
<style>
html, body, [class*="css"] { font-family: "Segoe UI", Arial, sans-serif; }
.block-container { max-width: 1240px; padding-top: 1.25rem; padding-bottom: 3rem; }
.stApp { background: #FFFFFF; color: #22252A; }

/* Reference-style catalog sidebar */
section[data-testid="stSidebar"] {
  background: #B7C4B6;
  border-right: 1px solid #A4B1A4;
}
section[data-testid="stSidebar"] > div {
  background: #B7C4B6;
  padding: 18px 16px 12px 16px;
}
section[data-testid="stSidebar"] [data-testid="stSidebarUserContent"] {
  padding-top: 8px !important;
  padding-bottom: 12px !important;
}
section[data-testid="stSidebar"] [data-testid="stMarkdownContainer"],
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] p {
  color: #22252A;
}
section[data-testid="stSidebar"] [data-testid="stSidebarNav"] { display: none; }
section[data-testid="stSidebar"] [data-testid="stVerticalBlock"] { gap: 0.2rem; }
section[data-testid="stSidebar"] hr { border: none; border-top: 1px solid #A4B1A4; margin: 14px 0 10px; }

.brand-mark {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 12px;
  width: calc(100% + 32px);
  height: 58px;
  min-width: 0;
  overflow: hidden;
  color: #22252A;
  border-bottom: 1px solid #A4B1A4;
  margin: -18px -16px 14px -16px;
  padding: 0 18px;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.8px;
}
.brand-mark img {
  display: block;
  flex: 0 0 42px;
  width: 42px;
  height: 42px;
  object-fit: contain;
  border-radius: 8px;
}
.brand-mark span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sidebar-section {
  color: #646D75;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 1.8px;
  text-transform: uppercase;
  margin: 10px 8px 0;
  padding-bottom: 10px;
}
section[data-testid="stSidebar"] [data-testid="stElementContainer"]:has([data-testid="stRadioGroup"]) {
  width: 100% !important;
}
section[data-testid="stSidebar"] .st-key-menu {
  width: 100% !important;
  margin-top: 16px !important;
}
section[data-testid="stSidebar"] [data-testid="stRadio"] {
  width: 100% !important;
}
section[data-testid="stSidebar"] [role="radiogroup"] {
  gap: 2px;
  width: 100%;
  padding-top: 8px;
  box-sizing: content-box;
}
section[data-testid="stSidebar"] [role="radiogroup"] > div {
  width: 100%;
}
section[data-testid="stSidebar"] [role="radiogroup"] label {
  display: flex;
  width: 100%;
  box-sizing: border-box;
  min-height: 42px;
  border-radius: 6px;
  margin: 0;
  padding: 0 12px;
  border: 1px solid transparent;
  align-items: center;
  font-size: 14px;
  color: #22252A;
}
section[data-testid="stSidebar"] [role="radiogroup"] label > div > div[data-testid="stMarkdownContainer"] {
  width: 100%;
}
section[data-testid="stSidebar"] [role="radiogroup"] label > div {
  display: flex;
  width: 100%;
  align-items: center;
}
section[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {
  background: #F5F6F5;
  border-color: #D5DDD6;
  color: #22252A;
  box-shadow: inset 3px 0 0 #5E7A65;
}
section[data-testid="stSidebar"] [role="radiogroup"] label:hover {
  background: #F5F6F5;
  color: #22252A;
}
section[data-testid="stSidebar"] [role="radiogroup"] input { display: none; }
section[data-testid="stSidebar"] [role="radiogroup"] label p { margin: 0; }
section[data-testid="stSidebar"] [role="radiogroup"] label > div > div:first-child { display: none; }

h1 { font-size: 22px !important; font-weight: 700 !important; line-height: 1.2 !important; margin-top: 0 !important; }
h2 { font-size: 18px !important; font-weight: 600 !important; line-height: 1.3 !important; }
div[data-testid="stMetric"] { background: #F5F6F5; border: 1px solid #E3E6E4; border-radius: 8px; padding: 16px; }
.block-container [data-testid="stMetric"] {
  min-height: 118px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.block-container [data-testid="stMetricLabel"] {
  color: #646D75;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.block-container [data-testid="stMetricValue"] {
  color: #22252A;
  font-family: "Segoe UI", Arial, sans-serif;
  font-size: 28px;
  font-weight: 700;
}
.block-container [data-testid="stDataFrame"] {
  border: 1px solid #E3E6E4;
  border-radius: 8px;
  overflow: hidden;
}
.alert-banner { background: #FFF4D4; border: 1px solid #E6D49A; border-radius: 8px; color: #7A5A12; padding: 12px 16px; margin: 12px 0; }
.status-dot { display:inline-block; width:6px; height:6px; border-radius:50%; margin-right:8px; vertical-align:middle; }
.healthy { background:#2E7D32; } .due { background:#EF6C00; } .overdue { background:#C62828; }
.status-label { color:#22252A; font-size:14px; font-weight:500; }
.stButton > button { border-radius:6px; min-height:40px; transition:none; animation:none; transform:none; }
.stButton > button[kind="primary"] { background:#5E7A65; border:none; }
.stButton > button[kind="secondary"] { background:#FFFFFF; color:#22252A; border:1px solid #D1D6D3; }
.stButton > button:hover, .stButton > button:active, .stButton > button:focus {
  transform:none;
  transition:none;
  animation:none;
}
hr { border-color:#E3E6E4; }

/* Remove Streamlit branding surfaces */
header[data-testid="stHeader"] { background: #FFFFFF; }
[data-testid="stAppDeployButton"] { display: none !important; }
[data-testid="stStatusWidget"] { visibility: hidden; }
footer { visibility: hidden; }

.st-key-login_card {
  background: #F5F6F5;
  border-color: #E3E6E4;
  border-radius: 8px;
  padding: 24px;
}
.landing-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
  color: #22252A;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0.8px;
}
.landing-brand img {
  display: block;
  width: 52px;
  height: 52px;
  object-fit: contain;
  border-radius: 8px;
}
.landing-note {
  color: #646D75;
  font-size: 13px;
  line-height: 1.55;
}
</style>
""", unsafe_allow_html=True)


def reset_cache():
    st.rerun()


def navigate_to(page_name):
    st.session_state.menu = page_name


NAV_ICONS = {
    "Dashboard": "⌂",
    "Add plant": "+",
    "Log watering": "◷",
    "Care notes": "✎",
    "Search and filter": "⌕",
    "Overdue alerts": "!",
    "Summary report": "▤",
    "Charts": "▥",
    "Import / Export": "⇅",
}


def rows_for(plants):
    rows = []
    for plant in plants:
        status = plant_status(plant)
        rows.append({
            "ID": plant["id"],
            "Plant": plant["name"],
            "Category": plant["category"].title(),
            "Location": plant["location"],
            "Interval": f"{plant['watering_interval']} days",
            "Last watered": plant["last_watered"],
            "Next due": status["next_due"],
            "Status": status["status"],
        })
    return rows


LOGO_PATH = Path(__file__).resolve().parent / "assets" / "logo-square.jpg"
logo_base64 = base64.b64encode(LOGO_PATH.read_bytes()).decode("ascii")

def activate_account(account):
    st.session_state.account_id = account["user_id"]
    st.session_state.signed_in_email = account["email"]
    st.session_state.menu = "Dashboard"
    st.rerun()


account = get_account(st.session_state.get("account_id"))
if account is None:
    st.session_state.pop("account_id", None)
    st.session_state.pop("signed_in_email", None)
    st.markdown(
        """
        <style>
        section[data-testid="stSidebar"] { display: none !important; }
        .block-container {
          max-width: 760px !important;
          padding-top: 4rem !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.markdown(
        f'<div class="landing-brand"><img src="data:image/jpeg;base64,{logo_base64}" '
        'alt="Plant Care logo"><span>PLANTCARE</span></div>',
        unsafe_allow_html=True,
    )
    st.title("Sign in to Plant Care Log")
    st.markdown(
        "Create an account or sign in to manage your plant records and care schedule."
    )
    with st.container(key="login_card", border=True):
        sign_in_tab, create_account_tab = st.tabs(["Sign in", "Create account"])
        with sign_in_tab:
            st.subheader("Welcome back")
            with st.form("sign_in_form", clear_on_submit=True):
                sign_in_email = st.text_input(
                    "Gmail address",
                    max_chars=254,
                    placeholder="you@gmail.com",
                )
                sign_in_password = st.text_input(
                    "Password",
                    type="password",
                    max_chars=128,
                    key="sign_in_password",
                )
                sign_in_submitted = st.form_submit_button(
                    "Sign in",
                    type="primary",
                    use_container_width=True,
                )
            if sign_in_submitted:
                try:
                    signed_in_account = authenticate_account(
                        sign_in_email,
                        sign_in_password,
                    )
                except ValueError as exc:
                    st.error(str(exc))
                else:
                    activate_account(signed_in_account)

        with create_account_tab:
            st.subheader("Create your account")
            with st.form("create_account_form", clear_on_submit=True):
                create_email = st.text_input(
                    "Gmail address",
                    max_chars=254,
                    placeholder="you@gmail.com",
                    key="create_account_email",
                )
                create_password = st.text_input(
                    "Password",
                    type="password",
                    max_chars=128,
                    key="create_account_password",
                )
                confirm_password = st.text_input(
                    "Confirm password",
                    type="password",
                    max_chars=128,
                    key="confirm_account_password",
                )
                create_submitted = st.form_submit_button(
                    "Create account",
                    type="primary",
                    use_container_width=True,
                )
            if create_submitted:
                if create_password != confirm_password:
                    st.error("The passwords do not match.")
                else:
                    try:
                        new_account = create_account(create_email, create_password)
                    except ValueError as exc:
                        st.error(str(exc))
                    else:
                        activate_account(new_account)

        st.markdown(
            '<p class="landing-note">Use a @gmail.com address and a password of at '
            'least 8 characters. Passwords are stored as salted hashes. Password '
            'reset is not available, so use a unique password.</p>',
            unsafe_allow_html=True,
        )
    st.stop()

account_id = account["user_id"]
account_data_dir = user_data_directory(account_id)
plants_csv_path = account_data_dir / "plants.csv"
import_errors_path = account_data_dir / "import_errors.csv"
data = load_plants(account_data_dir)


def sign_out():
    st.session_state.pop("account_id", None)
    st.session_state.pop("signed_in_email", None)


with st.sidebar:
    st.markdown(
        f'<div class="brand-mark"><img src="data:image/jpeg;base64,{logo_base64}" alt="Plant Care logo"><span>PLANTCARE</span></div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div class="sidebar-section">Plant care</div>', unsafe_allow_html=True)
    page = st.radio(
        "Menu",
        ["Dashboard", "Add plant", "Log watering", "Care notes", "Search and filter",
         "Overdue alerts", "Summary report", "Charts", "Import / Export"],
        label_visibility="collapsed",
        key="menu",
        format_func=lambda item: f"{NAV_ICONS[item]}  {item}",
    )
    st.markdown('<div class="sidebar-section">Account</div>', unsafe_allow_html=True)
    st.page_link("pages/privacy.py", label="Privacy")
    st.page_link("pages/terms.py", label="Terms")
    st.caption(f"Signed in as {st.session_state.signed_in_email}")
    st.button("Sign out", use_container_width=True, on_click=sign_out)


if page == "Dashboard":
    st.markdown('<span style="color:#646D75;font-size:12px;font-weight:600;">Workspace / Plant overview</span>', unsafe_allow_html=True)
    left, right = st.columns([1.25, 1], vertical_alignment="center")
    with left:
        st.title("Plant care overview")
    with right:
        a, b = st.columns(2)
        a.button(
            "Add plant",
            type="primary",
            use_container_width=True,
            on_click=navigate_to,
            args=("Add plant",),
        )
        with b:
            st.download_button(
                "Export CSV",
                plants_csv_path.read_bytes(),
                "plant-care.csv",
                "text/csv",
                use_container_width=True,
            )
    summary = summary_report(data)
    overdue = [p for p in data["plants"] if plant_status(p)["status"] == "Overdue"]
    if overdue:
        st.markdown(
            f'<div class="alert-banner"><strong>{len(overdue)} plants need watering.</strong> '
            f'Review the overdue list before scheduling care.</div>',
            unsafe_allow_html=True,
        )

    row1_left, row1_right = st.columns(2)
    row1_left.metric("Total plants", summary["total"])
    row1_right.metric("Overdue", summary["overdue_count"])

    row2_left, row2_right = st.columns(2)
    row2_left.metric("Average interval", f"{summary['average_interval']} days")
    row2_right.metric("Waterings, 30 days", summary["recent_waterings"])

    st.markdown(
        f'<div style="background:#F5F6F5;border:1px solid #E3E6E4;border-radius:8px;padding:14px 16px;margin:8px 0 18px">'
        f'<strong style="font-size:12px;color:#646D75;">WATERING ACTIVITY</strong>'
        f'<div style="display:flex;justify-content:space-between;margin-top:8px">'
        f'<span><strong style="font-size:22px;">{summary["recent_waterings"]}</strong> waterings</span>'
        f'<span style="color:#646D75;font-size:12px;">Last 30 days</span>'
        f'</div></div>',
        unsafe_allow_html=True,
    )

    st.subheader("Plant records")
    df = pd.DataFrame(rows_for(data["plants"]))
    st.dataframe(df, use_container_width=True, hide_index=True)

elif page == "Add plant":
    st.title("Add plant")
    with st.form("add_plant", clear_on_submit=True):
        c1, c2 = st.columns(2)
        name = c1.text_input("Plant name", max_chars=60)
        category = c2.selectbox("Category", CATEGORIES)
        location = c1.text_input("Location", max_chars=40)
        interval = c2.number_input("Watering interval (days)", min_value=1, max_value=60, value=7, step=1)
        last_watered = c1.date_input("Last watered", value=date.today(), max_value=date.today())
        notes = c2.text_area("Care notes", max_chars=500)
        submitted = st.form_submit_button("Save record", type="primary")
    if submitted:
        try:
            add_plant(
                data,
                name,
                category,
                location,
                int(interval),
                last_watered.isoformat(),
                notes,
                data_dir=account_data_dir,
            )
            st.success(f"{name.strip()} was added.")
            reset_cache()
        except ValueError as exc:
            st.error(str(exc))

elif page == "Log watering":
    st.title("Log watering")
    options = {f"{p['name']} ({p['id']})": p["id"] for p in data["plants"]}
    if not options:
        st.info("Add a plant before logging watering.")
    else:
        selected = st.selectbox("Plant", list(options))
        plant = next(p for p in data["plants"] if p["id"] == options[selected])
        with st.form("watering"):
            watered_date = st.date_input("Watering date", value=date.today(), max_value=date.today())
            note = st.text_area("Note")
            submitted = st.form_submit_button("Save watering", type="primary")
        if submitted:
            try:
                log_watering(
                    data,
                    options[selected],
                    watered_date.isoformat(),
                    note,
                    data_dir=account_data_dir,
                )
                st.success(f"Watering logged for {plant['name']}.")
                reset_cache()
            except ValueError as exc:
                st.error(str(exc))

elif page == "Care notes":
    st.title("Add or edit care notes")
    options = {f"{p['name']} ({p['id']})": p["id"] for p in data["plants"]}
    if options:
        selected = st.selectbox("Plant", list(options))
        plant = next(p for p in data["plants"] if p["id"] == options[selected])
        with st.form("edit_plant"):
            c1, c2 = st.columns(2)
            name = c1.text_input("Plant name", value=plant["name"], max_chars=60)
            category = c2.selectbox("Category", CATEGORIES, index=CATEGORIES.index(plant["category"]))
            location = c1.text_input("Location", value=plant["location"], max_chars=40)
            interval = c2.number_input("Watering interval", 1, 60, int(plant["watering_interval"]))
            last = date.fromisoformat(plant["last_watered"])
            last_watered = c1.date_input("Last watered", value=last, max_value=date.today())
            notes = c2.text_area("Care notes", value=plant["notes"], max_chars=500)
            submitted = st.form_submit_button("Save changes", type="primary")
        if submitted:
            try:
                update_plant(data, plant["id"], name, category, location, int(interval),
                             last_watered.isoformat(), notes, data_dir=account_data_dir)
                st.success("Care record updated.")
                reset_cache()
            except ValueError as exc:
                st.error(str(exc))

elif page == "Search and filter":
    st.title("Search and filter")
    c1, c2, c3, c4 = st.columns(4)
    keyword = c1.text_input("Keyword")
    category = c2.selectbox("Category", ["All"] + list(CATEGORIES))
    locations = ["All"] + sorted({p["location"] for p in data["plants"]})
    location = c3.selectbox("Location", locations)
    status = c4.selectbox("Status", ["All", "Healthy", "Due soon", "Overdue"])
    plants = filter_plants(data, keyword, category, location, status)
    st.caption(f"{len(plants)} matching record(s)")
    st.dataframe(pd.DataFrame(rows_for(plants)), use_container_width=True, hide_index=True)

elif page == "Overdue alerts":
    st.title("Overdue alerts")
    overdue = [p for p in data["plants"] if plant_status(p)["status"] == "Overdue"]
    due = [p for p in data["plants"] if plant_status(p)["status"] == "Due soon"]
    if overdue:
        st.markdown("### Overdue")
        for plant in overdue:
            info = plant_status(plant)
            st.markdown(
                f'<span class="status-dot overdue"></span>'
                f'<span class="status-label">{plant["name"]} — {info["overdue_days"]} day(s) late</span>',
                unsafe_allow_html=True,
            )
    if due:
        st.markdown("### Due soon")
        for plant in due:
            st.markdown(
                f'<span class="status-dot due"></span>'
                f'<span class="status-label">{plant["name"]} — due {plant_status(plant)["next_due"]}</span>',
                unsafe_allow_html=True,
            )
    if not overdue and not due:
        st.markdown(
            '<span class="status-dot healthy"></span>'
            '<span class="status-label">No urgent watering tasks</span>',
            unsafe_allow_html=True,
        )

elif page == "Summary report":
    st.title("Summary report")
    report = summary_report(data)
    c1, c2, c3 = st.columns(3)
    c1.metric("Total plants", report["total"])
    c2.metric("Overdue plants", report["overdue_count"])
    c3.metric("Average interval", f"{report['average_interval']} days")
    st.markdown("### Plants per category")
    st.dataframe(pd.DataFrame([{"Category": k.title(), "Count": v} for k, v in report["categories"].items()]),
                 use_container_width=True, hide_index=True)
    st.markdown("### Most neglected")
    if report["most_neglected"]:
        p = report["most_neglected"]
        st.write(f"{p['name']} ({plant_status(p)['days_since']} days since watering)")
    st.metric("Waterings in the last 30 days", report["recent_waterings"])

elif page == "Charts":
    st.title("Care charts")
    chart_defaults = {
        "Watering count per plant": ("Watering count per plant", "Waterings", "Plant"),
        "Plants per category": ("Plants per category", "Category", "Plants"),
        "Waterings over time": ("Waterings over time", "Date", "Waterings"),
    }
    chart_type = st.selectbox("Chart", list(chart_defaults))
    default_title, default_x_label, default_y_label = chart_defaults[chart_type]
    chart_key = chart_type.lower().replace(" ", "_")
    with st.expander("Edit chart text", expanded=True):
        title_column, x_column, y_column = st.columns(3)
        chart_title = title_column.text_input(
            "Chart title",
            default_title,
            max_chars=80,
            key=f"chart_title_{chart_key}",
        )
        x_label = x_column.text_input(
            "X-axis label",
            default_x_label,
            max_chars=80,
            key=f"chart_x_label_{chart_key}",
        )
        y_label = y_column.text_input(
            "Y-axis label",
            default_y_label,
            max_chars=80,
            key=f"chart_y_label_{chart_key}",
        )
    fig, ax = plt.subplots(figsize=(9, 4))
    if chart_type == "Plants per category":
        counts = {c: sum(p["category"] == c for p in data["plants"]) for c in CATEGORIES}
        ax.bar([c.title() for c in counts], list(counts.values()), color="#5E7A65")
    elif chart_type == "Watering count per plant":
        plant_counts = [
            (
                plant,
                sum(
                    item["plant_id"] == plant["id"]
                    for item in data["watering_history"]
                ),
            )
            for plant in data["plants"]
        ]
        plant_counts.sort(key=lambda item: item[1], reverse=True)
        plant_counts = plant_counts[:12]
        if any(count for _, count in plant_counts):
            ax.barh(
                [plant["name"] for plant, _ in plant_counts],
                [count for _, count in plant_counts],
                color="#5E7A65",
            )
            ax.invert_yaxis()
        else:
            ax.text(
                0.5,
                0.5,
                "No watering records yet",
                ha="center",
                va="center",
                transform=ax.transAxes,
            )
            ax.set_xlim(0, 1)
    else:
        daily = {}
        for item in data["watering_history"]:
            daily[item["date"]] = daily.get(item["date"], 0) + 1
        dates = sorted(daily)
        ax.plot(dates, [daily[d] for d in dates], color="#5E7A65", marker="o", markersize=3)
        fig.autofmt_xdate()
    ax.set_title(chart_title, parse_math=False)
    ax.set_xlabel(x_label, parse_math=False)
    ax.set_ylabel(y_label, parse_math=False)
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(colors="#646D75")
    fig.tight_layout()
    st.pyplot(fig)

elif page == "Import / Export":
    st.title("Import and export")
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Import CSV")
        uploaded = st.file_uploader("Select CSV", type=["csv"])
        import_clicked = st.button(
            "Import records",
            type="primary",
            disabled=uploaded is None,
        )
        if import_clicked and uploaded is not None:
            csv_path = account_data_dir / "upload.csv"
            with open(csv_path, "wb") as handle:
                handle.write(uploaded.getbuffer())
            try:
                accepted, errors = import_csv(
                    csv_path,
                    data,
                    data_dir=account_data_dir,
                )
                st.success(f"{accepted} records imported.")
                if errors:
                    st.warning(
                        f"{len(errors)} rows skipped. Details saved to your account data folder."
                    )
                    if import_errors_path.exists():
                        st.download_button(
                            "Download import error log",
                            import_errors_path.read_bytes(),
                            "import_errors.csv",
                            "text/csv",
                        )
            except (csv.Error, OSError, UnicodeError, ValueError) as exc:
                st.error(f"Import failed: {exc}")
    with c2:
        st.subheader("Export")
        st.download_button(
            "Download CSV",
            plants_csv_path.read_bytes(),
            "plant-care.csv",
            "text/csv",
        )
        markdown_path = account_data_dir / "plant-care-report.md"
        export_markdown(data, markdown_path)
        st.download_button(
            "Download Markdown",
            markdown_path.read_bytes(),
            "plant-care-report.md",
            "text/markdown",
        )
        text_report = io.StringIO()
        text_report.write("Plant Care Report\n\n")
        for plant in data["plants"]:
            status = plant_status(plant)
            text_report.write(
                f"{plant['id']} | {plant['name']} | {plant['category']} | "
                f"{plant['location']} | last: {plant['last_watered']} | "
                f"{status['status']} | due: {status['next_due']}\n"
            )
        st.download_button("Download text", text_report.getvalue(), "plant-care-report.txt", "text/plain")

