# Plant Care Log

A complete terminal, Tkinter, and Streamlit plant care dashboard.

## Run the website

```powershell
python -m streamlit run app.py
```

Open the local address shown in the terminal, normally `http://localhost:8501`.
On Windows, `run.bat` starts the same command.

The website opens with a sign-in screen. It checks for a `@gmail.com` email
address and a password of 8 to 128 characters. Use **Create account** to register,
then sign in with those credentials. Passwords are stored as salted PBKDF2 hashes,
and each account has its own plant records. Password reset and email verification
are not available. Use a unique password.

## Run the terminal interface

```powershell
python terminal_app.py
```

## Run the Tkinter interface

```powershell
python tk_app.py
```

Website accounts are stored in `data/accounts.sqlite3`; each account's plant
records are stored under `data/users/`. These files are created on first use and
should not be included in public source archives.

The terminal and Tkinter interfaces continue to use shared project data in
`data/plants.json` and `data/plants.csv`.

On the Charts page, use **Edit chart text** to change the title and axis labels.
Updates are applied to the chart immediately.
