(() => {
  "use strict";

  const STORAGE_KEY = "pathwise.student.v1";
  const AUTH_STORAGE_KEY = "pathwise.auth.v1";
  const PASSWORD_ITERATIONS = 150000;
  const BRANCHES = ["Computer Science", "Electronics", "Mechanical", "Electrical", "Civil"];
  const CAREERS = [
    "Full-Stack Web Developer", "Data Scientist", "Embedded Systems Engineer",
    "AI/ML Engineer", "Cybersecurity Engineer", "Mechanical Design Engineer",
    "Power Systems Engineer", "Structural Engineer"
  ];
  const COURSES = [
    { code: "ENGR101", name: "Engineering Design", semester: 1, credits: 3, difficulty: "Introductory", branches: ["all"], prerequisites: [], keywords: ["design", "foundations"], description: "An introduction to structured problem solving, design constraints, and technical communication." },
    { code: "MATH101", name: "Calculus I", semester: 1, credits: 4, difficulty: "Introductory", branches: ["all"], prerequisites: [], keywords: ["math", "calculus"], description: "Limits, derivatives, and their applications in engineering." },
    { code: "PHYS101", name: "Physics: Mechanics", semester: 1, credits: 4, difficulty: "Introductory", branches: ["all"], prerequisites: [], keywords: ["physics", "mechanics"], description: "Motion, forces, energy, and momentum with engineering applications." },
    { code: "CS101", name: "Programming Fundamentals", semester: 1, credits: 3, difficulty: "Introductory", branches: ["Computer Science", "Electronics", "Electrical", "Mechanical", "Civil"], prerequisites: [], keywords: ["coding", "python", "programming"], description: "Build core programming skills with variables, control flow, functions, and debugging." },
    { code: "ECE101", name: "Circuit Analysis", semester: 1, credits: 4, difficulty: "Introductory", branches: ["Electronics", "Electrical"], prerequisites: [], keywords: ["circuits", "electronics"], description: "Analyze DC circuits, components, and basic measurement techniques." },
    { code: "ME101", name: "Engineering Graphics", semester: 1, credits: 3, difficulty: "Introductory", branches: ["Mechanical", "Civil"], prerequisites: [], keywords: ["design", "cad", "drawing"], description: "Represent engineering components and systems using technical drawings." },
    { code: "MATH102", name: "Calculus II", semester: 2, credits: 4, difficulty: "Intermediate", branches: ["all"], prerequisites: ["MATH101"], keywords: ["math", "calculus", "integrals"], description: "Integration, sequences, and series for engineering analysis." },
    { code: "CS102", name: "Data Structures", semester: 2, credits: 4, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical", "Mechanical", "Civil"], prerequisites: ["CS101"], keywords: ["coding", "algorithms", "programming"], description: "Organize and work with data using lists, trees, hash tables, and graphs." },
    { code: "CHEM101", name: "Materials and Chemistry", semester: 2, credits: 3, difficulty: "Introductory", branches: ["all"], prerequisites: [], keywords: ["materials", "chemistry"], description: "Explore material properties, chemical principles, and selection in engineering." },
    { code: "ECE102", name: "Digital Logic", semester: 2, credits: 3, difficulty: "Intermediate", branches: ["Electronics", "Electrical"], prerequisites: ["ECE101"], keywords: ["circuits", "logic", "electronics"], description: "Design combinational and sequential circuits using Boolean logic." },
    { code: "ME102", name: "Statics and Materials", semester: 2, credits: 4, difficulty: "Intermediate", branches: ["Mechanical", "Civil"], prerequisites: ["PHYS101"], keywords: ["mechanics", "materials"], description: "Study force equilibrium, stress, strain, and basic material behavior." },
    { code: "CS103", name: "Discrete Mathematics", semester: 3, credits: 3, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["MATH101"], keywords: ["math", "logic", "proofs"], description: "Use logic, sets, combinatorics, and graph theory to reason about computing." },
    { code: "CS201", name: "Algorithms", semester: 3, credits: 4, difficulty: "Advanced", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS102", "CS103"], keywords: ["coding", "algorithms", "complexity"], description: "Analyze algorithm correctness and efficiency; apply core design techniques." },
    { code: "MATH201", name: "Linear Algebra", semester: 3, credits: 3, difficulty: "Intermediate", branches: ["all"], prerequisites: ["MATH101"], keywords: ["math", "matrices", "data"], description: "Vectors, matrices, and linear systems used throughout engineering." },
    { code: "ECE201", name: "Signals and Systems", semester: 3, credits: 4, difficulty: "Intermediate", branches: ["Electronics", "Electrical"], prerequisites: ["ECE102", "MATH102"], keywords: ["signals", "circuits"], description: "Model continuous and discrete signals and analyze linear systems." },
    { code: "ME201", name: "Thermodynamics", semester: 3, credits: 4, difficulty: "Intermediate", branches: ["Mechanical"], prerequisites: ["PHYS101", "MATH102"], keywords: ["energy", "mechanics"], description: "Apply energy balances and thermodynamic laws to engineering systems." },
    { code: "CIV201", name: "Structural Mechanics", semester: 3, credits: 4, difficulty: "Intermediate", branches: ["Civil"], prerequisites: ["ME102", "MATH102"], keywords: ["structures", "mechanics"], description: "Analyze internal forces and deformation in basic structural elements." },
    { code: "CS202", name: "Database Systems", semester: 4, credits: 3, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS102"], keywords: ["data", "sql", "backend"], description: "Design relational data models and write queries for transactional systems." },
    { code: "CS203", name: "Computer Systems", semester: 4, credits: 4, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS101"], keywords: ["hardware", "systems", "embedded"], description: "Understand how processors, memory, and operating systems execute programs." },
    { code: "MATH202", name: "Probability and Statistics", semester: 4, credits: 3, difficulty: "Intermediate", branches: ["all"], prerequisites: ["MATH102"], keywords: ["math", "statistics", "data"], description: "Use probability models and statistical methods to reason from data." },
    { code: "ECE202", name: "Microcontrollers", semester: 4, credits: 4, difficulty: "Intermediate", branches: ["Electronics", "Electrical"], prerequisites: ["ECE102", "CS101"], keywords: ["embedded", "hardware", "coding"], description: "Program microcontrollers and connect firmware to sensors and actuators." },
    { code: "ME202", name: "Machine Design", semester: 4, credits: 4, difficulty: "Advanced", branches: ["Mechanical"], prerequisites: ["ME102"], keywords: ["design", "mechanics", "cad"], description: "Select and size mechanical components using engineering design principles." },
    { code: "CIV202", name: "Surveying and Geomatics", semester: 4, credits: 3, difficulty: "Intermediate", branches: ["Civil"], prerequisites: ["MATH101"], keywords: ["surveying", "structures"], description: "Measure, map, and interpret spatial information for civil projects." },
    { code: "CS204", name: "Computer Networks", semester: 5, credits: 3, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS203"], keywords: ["networks", "systems", "security"], description: "Explore network protocols, routing, and the layered internet architecture." },
    { code: "CS205", name: "Software Engineering", semester: 5, credits: 3, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS201"], keywords: ["software", "teamwork", "design"], description: "Plan, build, test, and maintain software with reliable team practices." },
    { code: "CS301", name: "Web Application Engineering", semester: 5, credits: 4, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS202", "CS205"], keywords: ["web", "frontend", "backend", "full stack"], description: "Build accessible web applications with client, server, and data layers." },
    { code: "ECE301", name: "Embedded Systems", semester: 5, credits: 4, difficulty: "Advanced", branches: ["Electronics", "Electrical"], prerequisites: ["ECE202", "CS203"], keywords: ["embedded", "firmware", "hardware"], description: "Design resource-aware embedded applications that integrate hardware and software." },
    { code: "ME301", name: "Manufacturing Processes", semester: 5, credits: 3, difficulty: "Intermediate", branches: ["Mechanical"], prerequisites: ["ME202"], keywords: ["manufacturing", "design"], description: "Compare manufacturing methods and their impact on product design." },
    { code: "CIV301", name: "Geotechnical Engineering", semester: 5, credits: 3, difficulty: "Intermediate", branches: ["Civil"], prerequisites: ["CIV201", "CHEM101"], keywords: ["soil", "structures"], description: "Evaluate soil properties and their role in foundation engineering." },
    { code: "CS302", name: "Machine Learning", semester: 6, credits: 4, difficulty: "Advanced", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS201", "MATH201", "MATH202"], keywords: ["ai", "ml", "data", "python"], description: "Train and evaluate predictive models using statistical and computational methods." },
    { code: "CS303", name: "Cybersecurity Foundations", semester: 6, credits: 3, difficulty: "Intermediate", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS203", "CS204"], keywords: ["security", "networks", "systems"], description: "Apply security principles to systems, networks, identity, and data." },
    { code: "ECE302", name: "Digital Signal Processing", semester: 6, credits: 4, difficulty: "Advanced", branches: ["Electronics", "Electrical"], prerequisites: ["ECE201"], keywords: ["signals", "dsp", "electronics"], description: "Analyze and process sampled signals using practical digital techniques." },
    { code: "EE301", name: "Power Systems", semester: 6, credits: 4, difficulty: "Advanced", branches: ["Electrical"], prerequisites: ["ECE201"], keywords: ["power", "energy", "circuits"], description: "Model electrical power generation, transmission, and distribution systems." },
    { code: "ME302", name: "Control Systems", semester: 6, credits: 4, difficulty: "Advanced", branches: ["Mechanical"], prerequisites: ["ME201", "MATH201"], keywords: ["control", "automation", "systems"], description: "Model dynamic systems and design feedback controllers." },
    { code: "CIV302", name: "Transportation Engineering", semester: 6, credits: 3, difficulty: "Intermediate", branches: ["Civil"], prerequisites: ["CIV202", "MATH202"], keywords: ["transport", "infrastructure"], description: "Plan and evaluate safe, efficient transportation infrastructure." },
    { code: "CS304", name: "Cloud and Distributed Systems", semester: 7, credits: 4, difficulty: "Advanced", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS204", "CS301"], keywords: ["cloud", "distributed", "web"], description: "Design scalable services and reason about distributed data and failure." },
    { code: "CS305", name: "Data Science Practice", semester: 7, credits: 3, difficulty: "Advanced", branches: ["Computer Science", "Electronics", "Electrical"], prerequisites: ["CS302", "CS202"], keywords: ["data", "science", "analytics"], description: "Develop reproducible data workflows from data preparation through communication." },
    { code: "ECE401", name: "IoT Systems Studio", semester: 7, credits: 4, difficulty: "Advanced", branches: ["Electronics", "Electrical"], prerequisites: ["ECE301", "CS204"], keywords: ["iot", "embedded", "networks"], description: "Integrate connected devices, embedded software, and networked services." },
    { code: "ME401", name: "Robotics and Automation", semester: 7, credits: 4, difficulty: "Advanced", branches: ["Mechanical"], prerequisites: ["ME302", "CS102"], keywords: ["robotics", "automation", "embedded"], description: "Combine mechanisms, sensing, and control to automate physical tasks." },
    { code: "CIV401", name: "Sustainable Infrastructure", semester: 7, credits: 3, difficulty: "Advanced", branches: ["Civil"], prerequisites: ["CIV301", "CIV302"], keywords: ["sustainability", "infrastructure"], description: "Assess infrastructure systems using environmental and lifecycle considerations." },
    { code: "CS401", name: "Engineering Capstone", semester: 8, credits: 4, difficulty: "Advanced", branches: ["all"], prerequisites: ["ENGR101", "MATH102"], keywords: ["project", "design", "capstone"], description: "Deliver a scoped engineering project and document its design and evaluation." }
  ];

  const CAREER_CODES = {
    "Full-Stack Web Developer": ["CS202", "CS204", "CS205", "CS301", "CS304"],
    "Data Scientist": ["CS201", "MATH201", "MATH202", "CS302", "CS305"],
    "Embedded Systems Engineer": ["CS203", "ECE202", "ECE301", "ECE401"],
    "AI/ML Engineer": ["CS201", "MATH201", "MATH202", "CS302"],
    "Cybersecurity Engineer": ["CS203", "CS204", "CS303"],
    "Mechanical Design Engineer": ["ME102", "ME202", "ME301", "ME401"],
    "Power Systems Engineer": ["ECE201", "EE301", "ECE302"],
    "Structural Engineer": ["ME102", "CIV201", "CIV301", "CIV401"]
  };
  const BRANCH_CODES = {
    "Computer Science": ["CS103", "CS201", "CS202", "CS203", "CS204", "CS205", "CS301", "CS302", "CS303", "CS304", "CS305"],
    "Electronics": ["ECE101", "ECE102", "ECE201", "ECE202", "ECE301", "ECE302", "ECE401", "CS102", "CS203", "CS204"],
    "Mechanical": ["ME101", "ME102", "ME201", "ME202", "ME301", "ME302", "ME401"],
    "Electrical": ["ECE101", "ECE102", "ECE201", "ECE202", "ECE301", "ECE302", "EE301", "CS102", "CS203", "CS204"],
    "Civil": ["ME101", "ME102", "CIV201", "CIV202", "CIV301", "CIV302", "CIV401"]
  };
  const SHARED_CODES = ["ENGR101", "MATH101", "PHYS101", "CS101", "MATH102", "CHEM101", "MATH201", "MATH202", "CS401"];
  const YEAR_ROADMAP = [
    { year: 1, title: "Build foundations", tasks: ["Learn one programming language and engineering mathematics basics.", "Join one technical club or engineering society.", "Create a GitHub account and document one small project."] },
    { year: 2, title: "Develop core skills", tasks: ["Study branch fundamentals and data structures.", "Build and document a project related to your branch.", "Practice technical problem solving each week."] },
    { year: 3, title: "Choose a direction", tasks: ["Select a specialization and complete a focused project.", "Apply for internships or supervised industry experience.", "Choose a preparation track: placements, GATE, higher studies, or public service."] },
    { year: 4, title: "Prepare for transition", tasks: ["Complete a capstone and maintain a clear project portfolio.", "Prepare a role-specific resume and practice interviews.", "Track applications, exams, or postgraduate deadlines."] }
  ];
  const MOCK_TESTS = [
    {
      id: "mid-i", title: "First-year Mid-I", coverage: "Units 1-2", examType: "midterm",
      questions: [
        { prompt: "What is the derivative of x² with respect to x?", choices: ["x", "2x", "x²", "2"], answer: 1, explanation: "The power rule gives d(xⁿ)/dx = nxⁿ⁻¹, so d(x²)/dx = 2x." },
        { prompt: "Which C type is conventionally used to store a whole number?", choices: ["int", "char", "float", "void"], answer: 0, explanation: "The int type stores integer values." },
        { prompt: "The SI unit of force is:", choices: ["Joule", "Watt", "Newton", "Pascal"], answer: 2, explanation: "Force is measured in newtons (N)." },
        { prompt: "For a square matrix A, the identity matrix I satisfies:", choices: ["A + I = 0", "AI = A", "AI = I", "A/I = 1"], answer: 1, explanation: "Multiplying a matrix by the identity leaves it unchanged." },
        { prompt: "Ohm's law relates voltage V, current I, and resistance R as:", choices: ["V = IR", "I = VR", "R = VI", "V = I/R"], answer: 0, explanation: "Ohm's law is V = IR for an ohmic conductor under fixed conditions." },
        { prompt: "Which loop checks its condition before the first iteration in C?", choices: ["do-while", "while", "Both always execute once", "Neither"], answer: 1, explanation: "A while loop checks its condition before executing the body." },
        { prompt: "The area under a velocity-time graph represents:", choices: ["Acceleration", "Distance or displacement", "Jerk", "Momentum"], answer: 1, explanation: "Integrating velocity over time gives displacement; the signed area is displacement." },
        { prompt: "A covalent bond is formed primarily by:", choices: ["Sharing electrons", "Transferring protons", "Sharing neutrons", "Transferring nuclei"], answer: 0, explanation: "Covalent bonds involve shared pairs of electrons." },
        { prompt: "A technical drawing is mainly used to:", choices: ["Replace all calculations", "Communicate component geometry", "Measure temperature", "Store source code"], answer: 1, explanation: "Engineering drawings communicate shape, dimensions, and manufacturing intent." },
        { prompt: "Which statement about a C function is correct?", choices: ["It can group reusable instructions", "It must always return a float", "It cannot accept input", "It is only used for loops"], answer: 0, explanation: "Functions group reusable logic and may accept parameters or return a value." }
      ]
    },
    {
      id: "mid-ii", title: "First-year Mid-II", coverage: "Units 3-5", examType: "midterm",
      questions: [
        { prompt: "The integral of 2x with respect to x is:", choices: ["2x² + C", "x² + C", "x + C", "2 + C"], answer: 1, explanation: "The antiderivative of 2x is x² + C." },
        { prompt: "Which structure follows last-in, first-out order?", choices: ["Queue", "Stack", "Tree", "Graph"], answer: 1, explanation: "A stack removes the most recently added item first." },
        { prompt: "In a Python list, the first element is at index:", choices: ["-1", "0", "1", "Depends on list length"], answer: 1, explanation: "Python uses zero-based indexing." },
        { prompt: "The SI unit of electrical resistance is:", choices: ["Volt", "Ampere", "Ohm", "Coulomb"], answer: 2, explanation: "Resistance is measured in ohms (Ω)." },
        { prompt: "A vector field's divergence is a measure of:", choices: ["Local source or sink strength", "Path length", "Rotation only", "Scalar product"], answer: 0, explanation: "Divergence measures net outward flux density at a point." },
        { prompt: "Which search method requires sorted data for its usual efficient form?", choices: ["Linear search", "Binary search", "Depth-first search", "Hash lookup"], answer: 1, explanation: "Binary search repeatedly halves a sorted search interval." },
        { prompt: "In a series circuit, the current through ideal components is:", choices: ["Different at each component", "The same", "Always zero", "Equal to voltage"], answer: 1, explanation: "The same current flows through each element in a series path." },
        { prompt: "A Python function is declared using the keyword:", choices: ["function", "def", "make", "fn"], answer: 1, explanation: "Python uses def to define a function." },
        { prompt: "The first law of thermodynamics is a statement of conservation of:", choices: ["Charge", "Mass only", "Energy", "Angular momentum only"], answer: 2, explanation: "The first law expresses conservation of energy for a thermodynamic system." },
        { prompt: "In an engineering lab report, a conclusion should:", choices: ["Repeat the title only", "Relate findings to the objective", "Omit measured results", "Replace the method"], answer: 1, explanation: "A conclusion interprets the results in relation to the experiment's objective." }
      ]
    },
    {
      id: "see", title: "First-year semester-end", coverage: "Units 1-5", examType: "semester-end",
      questions: [
        { prompt: "Which operation is used to find the determinant of a square matrix?", choices: ["Matrix addition only", "A determinant expansion or row reduction", "Vector cross product", "Scalar integration"], answer: 1, explanation: "Determinants can be computed through expansion or suitable row operations." },
        { prompt: "Which C keyword exits the current loop immediately?", choices: ["stop", "break", "returnall", "exitloop"], answer: 1, explanation: "break terminates the nearest enclosing loop or switch." },
        { prompt: "The SI unit of power is:", choices: ["Joule", "Watt", "Newton", "Ampere"], answer: 1, explanation: "Power is measured in watts (W), equivalent to joules per second." },
        { prompt: "A queue typically follows:", choices: ["Last-in, first-out", "First-in, first-out", "Random order", "Sorted order"], answer: 1, explanation: "A queue processes items in first-in, first-out order." },
        { prompt: "For independent events A and B, P(A and B) equals:", choices: ["P(A) + P(B)", "P(A)P(B)", "P(A) - P(B)", "P(A)/P(B)"], answer: 1, explanation: "For independent events, the probability of both is the product of their probabilities." },
        { prompt: "In a balanced three-phase system, phase quantities are separated by:", choices: ["60°", "90°", "120°", "180°"], answer: 2, explanation: "The phase angles of a balanced three-phase system are 120 degrees apart." },
        { prompt: "The purpose of a free-body diagram is to show:", choices: ["All external forces on a body", "Only internal stress", "A component's color", "A circuit's voltage only"], answer: 0, explanation: "A free-body diagram isolates a body and represents the external forces and moments acting on it." },
        { prompt: "Which Python type is immutable?", choices: ["list", "dict", "tuple", "set"], answer: 2, explanation: "Tuples cannot be modified after creation." },
        { prompt: "In a lab, a repeated measurement is useful for estimating:", choices: ["Random variation", "Theoretical units", "A component's color", "The exam duration"], answer: 0, explanation: "Repeated measurements help identify variation and improve an estimate." },
        { prompt: "A good engineering design should account for:", choices: ["Only appearance", "Constraints, safety, and intended use", "Only the first idea", "No testing"], answer: 1, explanation: "Engineering design balances requirements, constraints, safety, and validation." }
      ]
    }
  ];
  const INTERVIEW_TOPICS = [
    { id: "programming", title: "Programming fundamentals", questions: [
      ["How would you explain the difference between a variable and a constant?", "A variable can be reassigned; a constant represents a value intended not to change. Language rules differ."],
      ["What is the purpose of a function?", "A function names a reusable unit of behavior, often with inputs and an output."],
      ["How do you approach debugging a program?", "Reproduce the issue, isolate the smallest failing case, inspect assumptions and state, fix the cause, then retest."],
      ["What is the difference between a compile-time and run-time error?", "A compile-time error is detected during translation or static checks; a run-time error occurs while executing."]
    ] },
    { id: "dsa", title: "Data structures and algorithms", questions: [
      ["When would you use a queue instead of a stack?", "A queue is useful when items should be processed in arrival order; a stack is useful for last-in, first-out behavior."],
      ["What does Big O notation describe?", "It describes how an algorithm's resource use grows with input size, commonly time or memory."],
      ["How does binary search reduce work?", "On sorted data, each comparison discards roughly half the remaining search interval."],
      ["What trade-off can a hash table introduce?", "It offers fast average-case lookup but uses extra memory and must handle collisions."]
    ] },
    { id: "systems", title: "Systems and networks", questions: [
      ["What is the role of an operating system?", "It manages hardware resources and provides abstractions and services for applications."],
      ["What is the difference between a process and a thread?", "A process has its own execution context and resources; threads are execution paths within a process that share resources."],
      ["Why is DNS used?", "DNS maps human-readable domain names to network records such as IP addresses."],
      ["What is the purpose of version control?", "It records changes, supports collaboration, and allows teams to inspect or restore earlier states."]
    ] },
    { id: "projects", title: "Project discussion", questions: [
      ["Describe a technical problem you solved and how you validated the result.", "State the problem, constraints, your contribution, the implementation, and evidence from tests or measurements."],
      ["What would you change if you rebuilt your project?", "Identify a specific limitation, explain its impact, and propose a practical improvement."],
      ["How did you divide work on a team project?", "Explain ownership, interfaces, coordination, and how integration issues were handled."],
      ["How do you decide what to build first?", "Prioritize by user value, risk, dependencies, and the smallest testable outcome."]
    ] }
  ];
  const CAREER_PATHS = [
    { id: "placements", title: "Private-sector placements", audience: "Campus and off-campus roles", description: "Build role-relevant fundamentals, projects, a concise resume, and interview practice. Openings and eligibility are controlled by each employer.", links: [{ label: "LinkedIn Jobs", url: "https://www.linkedin.com/jobs/" }, { label: "Naukri", url: "https://www.naukri.com/" }] },
    { id: "psu", title: "PSU and government engineering", audience: "GATE and direct recruitment routes", description: "Check each organization's current eligibility, examination route, and application dates. Requirements differ by employer and discipline.", links: [{ label: "GATE information", url: "https://gate2025.iitr.ac.in/" }, { label: "ISRO Careers", url: "https://www.isro.gov.in/Careers.html" }, { label: "BARC Careers", url: "https://www.barc.gov.in/careers/" }] },
    { id: "higher-studies", title: "Higher studies and research", audience: "M.Tech, MS, and research", description: "Compare entrance requirements, research areas, funding, and application deadlines before selecting programs.", links: [{ label: "NPTEL", url: "https://nptel.ac.in/" }, { label: "MIT OpenCourseWare", url: "https://ocw.mit.edu/" }] },
    { id: "public-service", title: "Public service and management", audience: "Civil services and management routes", description: "Plan around the published examination syllabus, eligibility rules, and official notices for each route.", links: [{ label: "UPSC", url: "https://www.upsc.gov.in/" }, { label: "National Apprenticeship Training Scheme", url: "https://nats.education.gov.in/" }] }
  ];
  const LEARNING_RESOURCES = [
    { label: "Virtual Labs", type: "Engineering laboratory practice", url: "https://www.vlab.co.in/" },
    { label: "CS50", type: "Computer science foundations", url: "https://cs50.harvard.edu/x/" },
    { label: "NPTEL", type: "Engineering courses", url: "https://nptel.ac.in/" },
    { label: "LeetCode", type: "Programming practice", url: "https://leetcode.com/" }
  ];
  const app = document.getElementById("app");
  const toast = document.getElementById("toast");
  let toastTimer;
  let accountEncryptionKey = null;
  let accountSaveQueue = Promise.resolve();
  let authAccounts = loadAuthAccounts();
  let legacyStudent = loadLegacyStudent();
  let state = defaultState();
  let authMode = "login";
  let emailDraft = "";
  let mobileMenuOpen = false;
  let mockTestSearchQuery = "";
  let mockTestSectionFilter = "";
  let interviewSearchQuery = "";
  let jobSearchQuery = "";

  function defaultState() {
    return {
      email: null, profile: null, completed: [], enrolled: [], activeCourse: null,
      assessmentMarks: {}, labMarks: {}, mockTestResults: [], activeTest: null, practicedQuestions: [],
      interviewSessions: [], mockInterview: null,
      resume: { fullName: "", headline: "", location: "", summary: "", skills: "", education: "", experience: "", projects: "", links: "" },
      savedJobs: [], roadmapTasks: [], activityDays: [], progressHistory: []
    };
  }

  function storedAccountData(value) {
    const defaults = defaultState();
    const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
    const resume = source.resume && typeof source.resume === "object" && !Array.isArray(source.resume) ? source.resume : {};
    const resumeFields = Object.keys(defaults.resume);
    const normalizedResume = {};
    for (const field of resumeFields) normalizedResume[field] = typeof resume[field] === "string" ? resume[field].slice(0, 5000) : "";
    return {
      profile: isValidProfile(source.profile) ? source.profile : null,
      completed: Array.isArray(source.completed) ? source.completed.filter(code => COURSES.some(course => course.code === code)) : [],
      enrolled: Array.isArray(source.enrolled) ? source.enrolled.filter(code => COURSES.some(course => course.code === code)) : [],
      assessmentMarks: source.assessmentMarks && typeof source.assessmentMarks === "object" && !Array.isArray(source.assessmentMarks) ? source.assessmentMarks : {},
      labMarks: source.labMarks && typeof source.labMarks === "object" && !Array.isArray(source.labMarks) ? source.labMarks : {},
      mockTestResults: Array.isArray(source.mockTestResults) ? source.mockTestResults.filter(item => item && typeof item === "object") : [],
      activeTest: source.activeTest && typeof source.activeTest === "object" ? source.activeTest : null,
      practicedQuestions: Array.isArray(source.practicedQuestions) ? source.practicedQuestions.filter(item => typeof item === "string") : [],
      interviewSessions: Array.isArray(source.interviewSessions) ? source.interviewSessions.filter(item => item && typeof item === "object") : [],
      mockInterview: source.mockInterview && typeof source.mockInterview === "object" ? source.mockInterview : null,
      resume: normalizedResume,
      savedJobs: Array.isArray(source.savedJobs) ? source.savedJobs.filter(item => typeof item === "string") : [],
      roadmapTasks: Array.isArray(source.roadmapTasks) ? source.roadmapTasks.filter(item => typeof item === "string") : [],
      activityDays: Array.isArray(source.activityDays)
        ? [...new Set(source.activityDays.filter(day => typeof day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(day)))].slice(-365)
        : [],
      progressHistory: Array.isArray(source.progressHistory)
        ? source.progressHistory.filter(item => item && /^\d{4}-\d{2}-\d{2}$/.test(item.date || "") &&
          Number.isFinite(Number(item.creditsCompleted)) && Number.isFinite(Number(item.totalCredits)) &&
          Number.isFinite(Number(item.coursesCompleted)) && Number(item.creditsCompleted) >= 0 &&
          Number(item.totalCredits) >= 0 && Number(item.coursesCompleted) >= 0)
          .slice(-90)
          .map(item => ({
            date: item.date,
            creditsCompleted: Number(item.creditsCompleted),
            totalCredits: Number(item.totalCredits),
            coursesCompleted: Number(item.coursesCompleted)
          }))
        : []
    };
  }

  function normalizeGmail(value) {
    const email = String(value || "").trim().toLowerCase();
    return /^[a-z0-9._%+-]+@gmail\.com$/.test(email) ? email : null;
  }

  function isValidProfile(profile) {
    return profile && BRANCHES.includes(profile.branch) &&
      Number.isInteger(profile.semester) && profile.semester >= 1 && profile.semester <= 8 &&
      ["None", "Beginner", "Intermediate"].includes(profile.coding) && CAREERS.includes(profile.goal);
  }

  function loadAuthAccounts() {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_KEY);
      if (!saved) return {};
      const parsed = JSON.parse(saved);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Saved accounts are invalid.");
      const accounts = {};
      for (const [rawEmail, value] of Object.entries(parsed)) {
        const email = normalizeGmail(rawEmail);
        if (!email || !value || typeof value !== "object" ||
            !/^[a-f0-9]{32}$/i.test(value.salt || "") ||
            !/^[a-f0-9]{64}$/i.test(value.passwordHash || "")) continue;
        const hasEncryptedData = /^[a-f0-9]{32}$/i.test(value.dataSalt || "") &&
          /^[a-f0-9]{24}$/i.test(value.dataIv || "") &&
          typeof value.encryptedData === "string" &&
          /^[A-Za-z0-9+/]+={0,2}$/.test(value.encryptedData);
        accounts[email] = hasEncryptedData
          ? {
            salt: value.salt, passwordHash: value.passwordHash, dataSalt: value.dataSalt,
            dataIv: value.dataIv, encryptedData: value.encryptedData, data: null, legacyRecord: null
          }
          : {
            salt: value.salt, passwordHash: value.passwordHash, data: storedAccountData(value),
            legacyRecord: value
          };
      }
      return accounts;
    } catch (error) {
      console.error("Pathwise could not load local accounts.", error);
      return {};
    }
  }

  function loadLegacyStudent() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Saved student data is invalid.");
      return { email: normalizeGmail(parsed.email), ...storedAccountData(parsed) };
    } catch (error) {
      console.error("Pathwise could not load saved progress.", error);
      return null;
    }
  }

  function serializeAuthAccounts(accounts) {
    const serialized = {};
    for (const [email, account] of Object.entries(accounts)) {
      if (account.encryptedData) {
        serialized[email] = {
          salt: account.salt,
          passwordHash: account.passwordHash,
          dataSalt: account.dataSalt,
          dataIv: account.dataIv,
          encryptedData: account.encryptedData
        };
      } else if (account.legacyRecord) {
        serialized[email] = account.legacyRecord;
      }
    }
    return serialized;
  }

  function saveState() {
    if (!state.email) return Promise.resolve(true);
    const email = state.email;
    const snapshot = storedAccountData(state);
    const save = async () => {
      const account = authAccounts[email];
      if (!account) {
        showToast("Create a local account before saving progress.");
        return false;
      }
      if (!accountEncryptionKey) {
        showToast("Sign in again before saving encrypted progress.");
        return false;
      }
      try {
        const dataSalt = account.dataSalt || bytesToHex(window.crypto.getRandomValues(new Uint8Array(16)));
        const encrypted = await encryptAccountData(snapshot, accountEncryptionKey);
        const updatedAccount = {
          ...account, dataSalt, dataIv: encrypted.dataIv, encryptedData: encrypted.encryptedData,
          data: snapshot, legacyRecord: null
        };
        const nextAccounts = { ...authAccounts, [email]: updatedAccount };
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(serializeAuthAccounts(nextAccounts)));
        authAccounts[email] = updatedAccount;
        return true;
      } catch (error) {
        console.error("Pathwise could not encrypt or save progress.", error);
        if (state.email === email) activateAccount(email);
        showToast("Progress could not be encrypted or saved in this browser.");
        return false;
      }
    };
    const operation = accountSaveQueue.then(save, save);
    accountSaveQueue = operation.then(() => undefined, () => undefined);
    return operation;
  }

  function activateAccount(email) {
    const account = authAccounts[email];
    const data = account.data || defaultState();
    state = {
      email,
      activeCourse: null,
      ...storedAccountData(data)
    };
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function dateKeyAtOffset(offset) {
    const date = new Date();
    date.setDate(date.getDate() + offset);
    return localDateKey(date);
  }

  function dayOrdinal(dateKey) {
    const [year, month, day] = dateKey.split("-").map(Number);
    return Math.floor(Date.UTC(year, month - 1, day) / 86400000);
  }

  function dateKeyFromOrdinal(ordinal) {
    const date = new Date(ordinal * 86400000);
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}-${String(date.getUTCDate()).padStart(2, "0")}`;
  }

  function streakSummary() {
    const activeDays = new Set(state.activityDays);
    const today = localDateKey(new Date());
    const activeToday = activeDays.has(today);
    let cursor = dayOrdinal(today) - (activeToday ? 0 : 1);
    let currentStreak = 0;
    while (activeDays.has(dateKeyFromOrdinal(cursor))) {
      currentStreak += 1;
      cursor -= 1;
    }
    const week = Array.from({ length: 7 }, (_, index) => {
      const dateKey = dateKeyAtOffset(index - 6);
      const date = new Date(`${dateKey}T12:00:00`);
      return {
        dateKey,
        label: date.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 2),
        title: date.toLocaleDateString(undefined, { weekday: "long", month: "short", day: "numeric" }),
        active: activeDays.has(dateKey),
        today: dateKey === today
      };
    });
    return { currentStreak, activeToday, week };
  }

  function recordActivity() {
    const today = localDateKey(new Date());
    if (!state.activityDays.includes(today)) {
      state.activityDays.push(today);
      state.activityDays = state.activityDays.slice(-365);
    }
  }

  function recordProgressSnapshot() {
    if (!state.profile) return;
    const roadmap = getRoadmap();
    const totalCredits = roadmap.reduce((total, course) => total + course.credits, 0);
    const completed = roadmap.filter(course => state.completed.includes(course.code));
    const snapshot = {
      date: localDateKey(new Date()),
      creditsCompleted: completed.reduce((total, course) => total + course.credits, 0),
      totalCredits,
      coursesCompleted: completed.length
    };
    state.progressHistory = state.progressHistory.filter(item => item.date !== snapshot.date);
    state.progressHistory.push(snapshot);
    state.progressHistory = state.progressHistory.slice(-90);
  }

  function streakMarkup() {
    const streak = streakSummary();
    const status = streak.activeToday
      ? `<span class="status status-completed"><span class="status-dot" aria-hidden="true"></span>Active today</span>`
      : streak.currentStreak
        ? `<span class="status status-progress"><span class="status-dot" aria-hidden="true"></span>Keep it going</span>`
        : `<span class="status status-available"><span class="status-dot" aria-hidden="true"></span>Ready to start</span>`;
    const weekMarkup = streak.week.map(day => `<div class="streak-day ${day.active ? "is-active" : ""} ${day.today ? "is-today" : ""}" title="${escapeHtml(day.title)}"><span>${escapeHtml(day.label)}</span><i aria-hidden="true"></i></div>`).join("");
    const message = streak.activeToday
      ? "Your learning activity is recorded for today."
      : streak.currentStreak
        ? "Complete a course, practice, or roadmap task today to continue."
        : "Complete a course, practice, or roadmap task to start a streak.";
    return `<section class="panel glass-panel streak-panel" aria-label="Daily learning streak"><div class="streak-heading"><div><p class="eyebrow">DAILY STREAK</p><div class="streak-count"><strong>${streak.currentStreak}</strong><span>${streak.currentStreak === 1 ? "day" : "days"}</span></div></div>${status}</div><div class="streak-week" role="group" aria-label="Activity for the last seven days">${weekMarkup}</div><p class="streak-copy">${message}</p></section>`;
  }

  function progressChartMarkup(totalCredits) {
    const entries = state.progressHistory.slice(-14);
    if (!entries.length) return `<div class="progress-chart-empty">Complete a course to start your progress graph.</div>`;
    const width = 640;
    const height = 190;
    const left = 38;
    const right = 12;
    const top = 14;
    const bottom = 34;
    const plotWidth = width - left - right;
    const plotHeight = height - top - bottom;
    const maxCredits = Math.max(1, totalCredits, ...entries.map(item => item.creditsCompleted));
    const points = entries.map((item, index) => {
      const x = entries.length === 1 ? left + plotWidth / 2 : left + (plotWidth * index) / (entries.length - 1);
      const y = top + plotHeight * (1 - item.creditsCompleted / maxCredits);
      return { ...item, x, y };
    });
    const polyline = points.map(point => `${point.x},${point.y}`).join(" ");
    const gridLines = [0, 0.5, 1].map(ratio => {
      const y = top + plotHeight * ratio;
      const label = Math.round(maxCredits * (1 - ratio));
      return `<line class="chart-grid-line" x1="${left}" y1="${y}" x2="${width - right}" y2="${y}"></line><text class="chart-axis-label" x="${left - 8}" y="${y + 3}" text-anchor="end">${label}</text>`;
    }).join("");
    const markers = points.map(point => {
      const date = new Date(`${point.date}T12:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" });
      return `<circle class="progress-point" cx="${point.x}" cy="${point.y}" r="3"><title>${escapeHtml(date)}: ${point.creditsCompleted} of ${point.totalCredits} credits</title></circle>`;
    }).join("");
    const firstDate = new Date(`${entries[0].date}T12:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const lastDate = new Date(`${entries[entries.length - 1].date}T12:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" });
    const dateLabels = entries.length === 1
      ? `<text class="chart-date-label" x="${left + plotWidth / 2}" y="${height - 8}" text-anchor="middle">${escapeHtml(firstDate)}</text>`
      : `<text class="chart-date-label" x="${left}" y="${height - 8}">${escapeHtml(firstDate)}</text><text class="chart-date-label" x="${width - right}" y="${height - 8}" text-anchor="end">${escapeHtml(lastDate)}</text>`;
    return `<svg class="progress-chart" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="progress-chart-title progress-chart-description"><title id="progress-chart-title">Credits completed over time</title><desc id="progress-chart-description">Daily snapshots of completed credits for this roadmap. The latest value is ${points[points.length - 1].creditsCompleted} of ${points[points.length - 1].totalCredits} credits.</desc>${gridLines}<polyline class="progress-line" points="${polyline}"></polyline>${markers}${dateLabels}</svg>`;
  }

  function bytesToHex(bytes) {
    return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
  }

  function hexToBytes(hex) {
    return new Uint8Array(hex.match(/.{2}/g).map(byte => parseInt(byte, 16)));
  }

  function bytesToBase64(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return window.btoa(binary);
  }

  function base64ToBytes(value) {
    const binary = window.atob(value);
    return Uint8Array.from(binary, character => character.charCodeAt(0));
  }

  async function hashPassword(password, salt) {
    if (!window.crypto || !window.crypto.subtle) {
      throw new Error("Password accounts require a secure browser context such as localhost or HTTPS.");
    }
    const key = await window.crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(password),
      "PBKDF2",
      false,
      ["deriveBits"]
    );
    const result = await window.crypto.subtle.deriveBits({
      name: "PBKDF2",
      salt: hexToBytes(salt),
      iterations: PASSWORD_ITERATIONS,
      hash: "SHA-256"
    }, key, 256);
    return bytesToHex(new Uint8Array(result));
  }

  async function deriveEncryptionKey(password, salt) {
    if (!window.crypto || !window.crypto.subtle) {
      throw new Error("Encrypted accounts require a secure browser context such as localhost or HTTPS.");
    }
    const material = await window.crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(password),
      "PBKDF2",
      false,
      ["deriveKey"]
    );
    return window.crypto.subtle.deriveKey({
      name: "PBKDF2",
      salt: hexToBytes(salt),
      iterations: PASSWORD_ITERATIONS,
      hash: "SHA-256"
    }, material, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
  }

  async function encryptAccountData(data, key) {
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(JSON.stringify(data));
    const ciphertext = await window.crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);
    return { dataIv: bytesToHex(iv), encryptedData: bytesToBase64(new Uint8Array(ciphertext)) };
  }

  async function decryptAccountData(account, key) {
    try {
      const plaintext = await window.crypto.subtle.decrypt(
        { name: "AES-GCM", iv: hexToBytes(account.dataIv) },
        key,
        base64ToBytes(account.encryptedData)
      );
      return storedAccountData(JSON.parse(new TextDecoder().decode(plaintext)));
    } catch (error) {
      console.error("Pathwise could not decrypt saved account data.", error);
      throw new Error("Saved account data could not be decrypted. It may be damaged; your data has not been changed.");
    }
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add("visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 2800);
  }

  function showAuthFeedback(message) {
    const error = document.getElementById("auth-error");
    if (!error) return;
    error.textContent = message;
    error.classList.add("visible");
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }

  function getRoute() {
    const match = window.location.hash.match(/^#\/(dashboard|catalog|mock-test|interview-prep|resume|mock-interview|assessment|jobs|profile|edit-profile|settings|course\/([A-Z0-9]+))$/);
    return match ? { page: match[1].startsWith("course/") ? "course" : match[1], code: match[2] || null } : { page: "dashboard", code: null };
  }

  function go(route) {
    const nextHash = `#/${route}`;
    if (window.location.hash === nextHash) {
      render();
      return;
    }
    window.location.hash = `/${route}`;
  }

  function getCoursesForProfile() {
    if (!state.profile) return [];
    const wanted = new Set([...SHARED_CODES, ...(BRANCH_CODES[state.profile.branch] || []), ...(CAREER_CODES[state.profile.goal] || [])]);
    const byCode = new Map(COURSES.map(course => [course.code, course]));
    const pending = [...wanted];
    while (pending.length) {
      const course = byCode.get(pending.pop());
      if (!course) continue;
      for (const prerequisite of course.prerequisites) {
        if (!wanted.has(prerequisite)) {
          wanted.add(prerequisite);
          pending.push(prerequisite);
        }
      }
    }
    return COURSES.filter(course => wanted.has(course.code));
  }

  function topologicalOrder(courses) {
    const byCode = new Map(courses.map(course => [course.code, course]));
    const indegree = new Map(courses.map(course => [course.code, 0]));
    const dependents = new Map(courses.map(course => [course.code, []]));
    for (const course of courses) {
      for (const prerequisite of course.prerequisites) {
        if (!byCode.has(prerequisite)) continue;
        indegree.set(course.code, indegree.get(course.code) + 1);
        dependents.get(prerequisite).push(course.code);
      }
    }
    const ready = courses.filter(course => indegree.get(course.code) === 0)
      .sort((a, b) => a.semester - b.semester || a.code.localeCompare(b.code));
    const sorted = [];
    while (ready.length) {
      const course = ready.shift();
      sorted.push(course);
      for (const dependentCode of dependents.get(course.code)) {
        indegree.set(dependentCode, indegree.get(dependentCode) - 1);
        if (indegree.get(dependentCode) === 0) {
          ready.push(byCode.get(dependentCode));
          ready.sort((a, b) => a.semester - b.semester || a.code.localeCompare(b.code));
        }
      }
    }
    if (sorted.length !== courses.length) throw new Error("The course catalog contains a prerequisite cycle.");
    return sorted;
  }

  function getRoadmap() {
    const completed = new Set(state.completed);
    const assignedTerm = new Map();
    const sorted = topologicalOrder(getCoursesForProfile());
    for (const course of sorted) {
      const unfinishedPrerequisiteTerms = course.prerequisites
        .filter(code => !completed.has(code) && assignedTerm.has(code))
        .map(code => assignedTerm.get(code));
      const earliestPrerequisiteTerm = unfinishedPrerequisiteTerms.length
        ? Math.max(...unfinishedPrerequisiteTerms) + 1
        : state.profile.semester;
      assignedTerm.set(course.code, Math.max(state.profile.semester, course.semester, earliestPrerequisiteTerm));
    }
    return sorted.map(course => ({ ...course, roadmapSemester: assignedTerm.get(course.code) }));
  }

  function prerequisitesMet(course) {
    const completed = new Set(state.completed);
    return course.prerequisites.every(code => completed.has(code));
  }

  function courseStatus(course) {
    if (state.completed.includes(course.code)) return "completed";
    if (state.enrolled.includes(course.code)) return "progress";
    return prerequisitesMet(course) ? "available" : "locked";
  }

  function statusLabel(status) {
    return ({ completed: "Completed", progress: "In progress", available: "Available", locked: "Locked" })[status];
  }

  function statusMarkup(status) {
    return `<span class="status status-${status}"><span class="status-dot" aria-hidden="true"></span>${statusLabel(status)}</span>`;
  }

  function codingGuidance() {
    if (state.profile.coding === "None") return "Start with Programming Fundamentals before taking Data Structures.";
    if (state.profile.coding === "Beginner") return "Build confidence in Programming Fundamentals before progressing to Data Structures.";
    return "Self-reported experience does not replace transcript prerequisites. Confirm course equivalency with your advisor.";
  }

  function prerequisiteText(course) {
    if (!course.prerequisites.length) return "No prerequisites";
    return course.prerequisites.join(", ");
  }

  function courseActions(course, status) {
    const details = `<button class="text-button" type="button" data-action="details" data-code="${course.code}">Details</button>`;
    if (status === "available") return `${details}<button class="button button-primary small-button" type="button" data-action="enroll" data-code="${course.code}">Enroll</button>`;
    if (status === "progress") return `${details}<button class="button button-secondary small-button" type="button" data-action="complete" data-code="${course.code}">Mark Complete</button>`;
    if (status === "locked") return `${details}<span class="lock-note">Prerequisites not met</span>`;
    return details;
  }

  function courseCard(course) {
    const status = courseStatus(course);
    return `<article class="course-card" data-course-code="${course.code}">
      <div class="course-card-main">
        <div class="course-card-info">
          <div class="course-code">${escapeHtml(course.code)} · ${course.credits} credits</div>
          <h3 class="course-title">${escapeHtml(course.name)}</h3>
          <p class="course-description">${escapeHtml(course.description)}</p>
          <div class="course-meta-row"><span>Prerequisites: ${escapeHtml(prerequisiteText(course))}</span><span>${escapeHtml(course.difficulty)}</span></div>
        </div>
        <div class="course-card-actions">${courseActions(course, status)}</div>
      </div>
    </article>`;
  }

  function footerLinks(className = "footer-inline") {
    return `<footer class="${className}"><a href="./privacy.html">Privacy Policy</a><a href="./terms.html">Terms &amp; Conditions</a></footer>`;
  }

  function renderLanding() {
    const creatingAccount = authMode === "signup";
    app.innerHTML = `<main class="signin-only-page">
      <section class="landing-signin" aria-labelledby="signin-heading">
        <div class="auth-brand"><span class="logo-image-crop auth-logo-crop"><img src="./pathwise-logo.jpg" alt="Pathwise" draggable="false"></span></div>
        <h1 id="signin-heading">${creatingAccount ? "Create account" : "Welcome back"}</h1>
        <p class="auth-subtitle">${creatingAccount ? "Create your local account" : "Sign in to your account"}</p>
        <form id="login-form" novalidate>
          <div class="form-field"><label for="login-email">Email</label><input class="field-control" id="login-email" name="email" type="email" autocomplete="email" placeholder="you@gmail.com" value="${escapeHtml(emailDraft)}" required></div>
          <div class="form-field password-field">
            <div class="auth-label-row"><label for="login-password">Password</label>${creatingAccount ? "" : `<button class="auth-text-button" type="button" data-action="forgot-password">Forgot password?</button>`}</div>
            <input class="field-control" id="login-password" name="password" type="password" autocomplete="${creatingAccount ? "new-password" : "current-password"}" minlength="8" required>
          </div>
          ${creatingAccount ? `<div class="form-field password-field"><label for="confirm-password">Confirm password</label><input class="field-control" id="confirm-password" name="confirmPassword" type="password" autocomplete="new-password" minlength="8" required></div>` : ""}
          <p class="form-error" id="auth-error" role="alert"></p>
          <button class="button button-primary signin-button" type="submit">${creatingAccount ? "Create account" : "Sign in"}</button>
        </form>
        <div class="signin-divider"><span>or</span></div>
        <button class="button button-secondary google-button" type="button" data-action="google-signin"><span class="google-mark" aria-hidden="true">G</span>Continue with Google</button>
        <p class="signin-disclaimer">${creatingAccount ? "Use a strong password you can remember. It encrypts your local data and cannot be recovered. Email is not verified and Google sign-in is not configured." : "Local demo only. Email is not verified, Google sign-in is not configured, and accounts do not sync between browsers."}</p>
        <p class="auth-switch-copy">${creatingAccount ? "Already have an account?" : "Need an account?"} <button class="auth-mode-link" type="button" data-auth-mode="${creatingAccount ? "login" : "signup"}">${creatingAccount ? "Sign in" : "Sign up"}</button></p>
      </section>
    </main>`;
    const emailInput = document.getElementById("login-email");
    emailInput.addEventListener("input", () => { emailDraft = emailInput.value; });
    document.querySelectorAll("[data-auth-mode]").forEach(button => {
      button.addEventListener("click", () => {
        emailDraft = emailInput.value;
        authMode = button.dataset.authMode;
        renderLanding();
      });
    });
    document.getElementById("login-form").addEventListener("submit", async event => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const email = normalizeGmail(data.get("email"));
      const password = String(data.get("password") || "");
      const error = document.getElementById("auth-error");
      if (!email) {
        error.textContent = "Enter a valid Gmail address ending in @gmail.com.";
        error.classList.add("visible");
        return;
      }
      emailDraft = email;
      if (password.length < 8) {
        error.textContent = "Use a password with at least 8 characters.";
        error.classList.add("visible");
        return;
      }
      try {
        if (creatingAccount) {
          if (authAccounts[email]) {
            error.textContent = "An account for this email already exists in this browser. Choose Sign in.";
            error.classList.add("visible");
            return;
          }
          if (password !== String(data.get("confirmPassword") || "")) {
            error.textContent = "The passwords do not match.";
            error.classList.add("visible");
            return;
          }
          const salt = bytesToHex(window.crypto.getRandomValues(new Uint8Array(16)));
          const dataSalt = bytesToHex(window.crypto.getRandomValues(new Uint8Array(16)));
          const passwordHash = await hashPassword(password, salt);
          accountEncryptionKey = await deriveEncryptionKey(password, dataSalt);
          const canRestoreLegacy = legacyStudent &&
            (legacyStudent.email === email || (!legacyStudent.email && Object.keys(authAccounts).length === 0));
          authAccounts[email] = {
            salt,
            passwordHash,
            dataSalt,
            data: storedAccountData(canRestoreLegacy ? legacyStudent : null),
            legacyRecord: null
          };
          activateAccount(email);
          if (!await saveState()) {
            delete authAccounts[email];
            accountEncryptionKey = null;
            state = defaultState();
            return;
          }
          if (canRestoreLegacy) {
            localStorage.removeItem(STORAGE_KEY);
            legacyStudent = null;
          }
        } else {
          const account = authAccounts[email];
          if (!account) {
            error.textContent = legacyStudent && legacyStudent.email === email
              ? "Set a password first using Create account for this saved profile."
              : "No local account was found. Choose Create account to register in this browser.";
            error.classList.add("visible");
            return;
          }
          const passwordHash = await hashPassword(password, account.salt);
          if (passwordHash !== account.passwordHash) {
            error.textContent = "Email or password is incorrect.";
            error.classList.add("visible");
            return;
          }
          const dataSalt = account.dataSalt || bytesToHex(window.crypto.getRandomValues(new Uint8Array(16)));
          const encryptionKey = await deriveEncryptionKey(password, dataSalt);
          const accountData = account.encryptedData
            ? await decryptAccountData(account, encryptionKey)
            : account.data || storedAccountData(null);
          authAccounts[email] = { ...account, dataSalt, data: accountData };
          accountEncryptionKey = encryptionKey;
          activateAccount(email);
          if (!await saveState()) {
            accountEncryptionKey = null;
            state = defaultState();
            return;
          }
          if (legacyStudent && legacyStudent.email === email) {
            localStorage.removeItem(STORAGE_KEY);
            legacyStudent = null;
          }
        }
        if (state.profile) go("dashboard");
        else renderOnboarding();
      } catch (authError) {
        accountEncryptionKey = null;
        if (creatingAccount && authAccounts[email] && !authAccounts[email].encryptedData) {
          delete authAccounts[email];
          state = defaultState();
        }
        console.error("Pathwise could not complete local password sign-in.", authError);
        error.textContent = authError.message || "Password sign-in could not be completed.";
        error.classList.add("visible");
      }
    });
  }

  function renderOnboarding() {
    app.innerHTML = `<div class="onboarding-shell">
      <aside class="onboarding-aside">
        <a class="brand" href="./index.html"><span class="logo-image-crop brand-logo-crop"><img src="./pathwise-logo.jpg" alt="Pathwise" draggable="false"></span></a>
        <div class="onboarding-aside-copy">
          <p class="eyebrow">ENGINEERING / COURSE PLANNER</p>
          <h1>Plan your next courses with prerequisites in view.</h1>
          <p>Set your branch, semester, coding experience, and career direction. Pathwise builds a course sequence you can review and track.</p>
        </div>
        <div class="onboarding-aside-foot">Your profile and progress stay in this browser.</div>
      </aside>
      <main class="onboarding-form-wrap">
        <form class="onboarding-form" id="diagnostic-form" novalidate>
          <p class="eyebrow">STUDENT PROFILE / 01</p>
          <h2>Build your roadmap</h2>
          <p>Choose your current context. You can update it later.</p>
          <div class="form-grid">
            <div class="form-field"><label for="branch">Engineering branch</label><select class="field-control" id="branch" name="branch" required><option value="">Select a branch</option>${BRANCHES.map(branch => `<option>${escapeHtml(branch)}</option>`).join("")}</select></div>
            <div class="form-field"><label for="semester">Current semester</label><select class="field-control" id="semester" name="semester" required><option value="">Select a semester</option>${Array.from({ length: 8 }, (_, index) => `<option value="${index + 1}">Semester ${index + 1}</option>`).join("")}</select><div class="form-help">Courses you have not completed remain visible until you mark them complete.</div></div>
            <div class="form-field"><label for="coding">Prior coding knowledge</label><select class="field-control" id="coding" name="coding" required><option value="">Select a level</option><option>None</option><option>Beginner</option><option>Intermediate</option></select></div>
            <div class="form-field"><label for="goal">Career target</label><select class="field-control" id="goal" name="goal" required><option value="">Select a career target</option>${CAREERS.map(goal => `<option>${escapeHtml(goal)}</option>`).join("")}</select></div>
          </div>
          <p class="form-error" id="form-error" role="alert"></p>
          <div class="form-actions"><span class="form-legal">By continuing, you agree to our <a href="./terms.html">Terms</a> and <a href="./privacy.html">Privacy Policy</a>.</span><button class="button button-primary" type="submit">Start Roadmap</button></div>
          ${state.profile ? `<button class="button button-quiet" style="margin-top:12px" type="button" data-action="back-dashboard">Return to saved roadmap</button>` : ""}
          <button class="button button-quiet" style="margin-top:8px" type="button" data-action="sign-out">Sign out</button>
          ${footerLinks()}
        </form>
      </main>
    </div>`;
    const form = document.getElementById("diagnostic-form");
    form.addEventListener("submit", async event => {
      event.preventDefault();
      const data = new FormData(form);
      const profile = {
        branch: String(data.get("branch") || ""),
        semester: Number(data.get("semester")),
        coding: String(data.get("coding") || ""),
        goal: String(data.get("goal") || "")
      };
      if (!BRANCHES.includes(profile.branch) || !Number.isInteger(profile.semester) || profile.semester < 1 || profile.semester > 8 || !["None", "Beginner", "Intermediate"].includes(profile.coding) || !CAREERS.includes(profile.goal)) {
        const error = document.getElementById("form-error");
        error.textContent = "Complete each field to build your roadmap.";
        error.classList.add("visible");
        return;
      }
      const roadmapChanged = !state.profile || state.profile.branch !== profile.branch ||
        state.profile.semester !== profile.semester || state.profile.goal !== profile.goal;
      state.profile = profile;
      state.completed = state.completed.filter(code => getCoursesForProfile().some(course => course.code === code));
      state.enrolled = state.enrolled.filter(code => getCoursesForProfile().some(course => course.code === code));
      if (roadmapChanged) state.progressHistory = [];
      recordProgressSnapshot();
      if (!await saveState()) return;
      go("dashboard");
    });
  }

  function shell(content, page) {
    const profileName = state.resume.fullName || state.profile.branch;
    const workspaceItems = [
      { route: "dashboard", label: "Roadmaps", icon: "⌂" },
      { route: "catalog", label: "Courses", icon: "▦" },
      { route: "mock-test", label: "Mock test", icon: "▤" },
      { route: "interview-prep", label: "Interview prep", icon: "◇" },
      { route: "resume", label: "Resume prep", icon: "▧" },
      { route: "mock-interview", label: "Mock interview", icon: "◷" },
      { route: "assessment", label: "Assessment", icon: "▣" },
      { route: "jobs", label: "Jobs", icon: "↗" }
    ];
    const accountItems = [
      { route: "profile", label: "My profile", icon: "profile" },
      { route: "edit-profile", label: "Edit profile", icon: "edit" },
      { route: "settings", label: "Settings", icon: "settings" }
    ];
    const navIconMarkup = icon => {
      const icons = {
        profile: `<svg class="nav-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3.5"></circle><path d="M4.5 20c.7-3.8 3.3-5.8 7.5-5.8s6.8 2 7.5 5.8"></path></svg>`,
        edit: `<svg class="nav-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"></path><path d="m16.5 3.5 4 4L9 19l-5 1 1-5z"></path></svg>`,
        settings: `<svg class="nav-icon-svg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3.2"></circle><path d="M12 2.8v2M12 19.2v2M21.2 12h-2M4.8 12h-2M18.5 5.5l-1.4 1.4M6.9 17.1l-1.4 1.4M18.5 18.5l-1.4-1.4M6.9 6.9 5.5 5.5"></path></svg>`
      };
      return icons[icon] || `<span class="nav-icon" aria-hidden="true">${icon}</span>`;
    };
    const navLinks = items => items.map(item =>
      `<a class="nav-link" href="#/${item.route}" ${page === item.route ? 'aria-current="page"' : ""}>${navIconMarkup(item.icon)}${item.label}</a>`
    ).join("");
    const workspaceNav = navLinks(workspaceItems);
    const accountNav = navLinks(accountItems);
    const mobileQuickLinks = ["dashboard", "catalog", "assessment"].map(route => {
      const item = workspaceItems.find(entry => entry.route === route);
      return `<a class="nav-link" href="#/${route}" ${page === route ? 'aria-current="page"' : ""}>${navIconMarkup(item.icon)}${item.label}</a>`;
    }).join("");
    app.innerHTML = `<div class="app-shell">
      <aside class="sidebar">
        <a class="brand" href="#/dashboard"><span class="logo-image-crop brand-logo-crop"><img src="./pathwise-logo.jpg" alt="Pathwise" draggable="false"></span></a>
        <p class="nav-label">Catalog</p>
        <nav class="primary-nav" aria-label="Workspace">${workspaceNav}</nav>
        <p class="nav-label account-nav-label">Account</p>
        <nav class="primary-nav" aria-label="Account">${accountNav}</nav>
        <div class="sidebar-spacer"></div>
        <div class="profile-mini"><span class="avatar" aria-hidden="true">${escapeHtml(profileName.split(" ").map(word => word[0]).slice(0, 2).join(""))}</span><div><div class="profile-mini-name">${escapeHtml(profileName)}</div><div class="profile-mini-sub">${escapeHtml(state.profile.branch)} · Sem ${state.profile.semester}</div></div></div>
        <div class="sidebar-footer"><a href="./privacy.html">Privacy</a><a href="./terms.html">Terms</a><button class="text-button signout-link" type="button" data-action="sign-out">Sign out</button></div>
      </aside>
      <div class="main-shell">
        <header class="topbar"><a class="brand mobile-brand" href="#/dashboard"><span class="logo-image-crop mobile-logo-crop"><img src="./pathwise-logo.jpg" alt="Pathwise" draggable="false"></span></a><div class="breadcrumb">Workspace <span aria-hidden="true">/</span> <strong>${pageTitle(page)}</strong></div><div class="topbar-right"><span class="topbar-dot" aria-hidden="true"></span>Local demo</div><button class="mobile-menu-toggle" type="button" data-action="toggle-mobile-menu" aria-expanded="${mobileMenuOpen}" aria-controls="mobile-menu">${mobileMenuOpen ? "Close" : "Menu"}</button></header>
        <main class="content">${content}</main>
      </div>
      <nav class="mobile-nav" aria-label="Quick navigation">${mobileQuickLinks}<button class="nav-link mobile-more" type="button" data-action="toggle-mobile-menu" aria-expanded="${mobileMenuOpen}" aria-controls="mobile-menu"><span class="nav-icon" aria-hidden="true">···</span>More</button></nav>
      <nav id="mobile-menu" class="mobile-drawer ${mobileMenuOpen ? "is-open" : ""}" aria-label="All workspace pages">${workspaceNav}<p class="nav-label account-nav-label">Account</p>${accountNav}<a class="nav-link" href="./privacy.html">Privacy</a><a class="nav-link" href="./terms.html">Terms</a><button class="nav-link drawer-signout" type="button" data-action="sign-out">Sign out</button></nav>
    </div>`;
  }

  function pageTitle(page) {
    return ({
      dashboard: "Roadmaps", catalog: "Courses", course: "Course details", "mock-test": "Mock test",
      "interview-prep": "Interview prep", resume: "Resume prep", "mock-interview": "Mock interview",
      assessment: "Assessment", jobs: "Jobs & pathways", profile: "My profile",
      "edit-profile": "Edit profile", settings: "Settings"
    })[page] || "Roadmaps";
  }

  function dashboard() {
    const roadmap = getRoadmap();
    const totalCredits = roadmap.reduce((sum, course) => sum + course.credits, 0);
    const completeCredits = roadmap.filter(course => state.completed.includes(course.code)).reduce((sum, course) => sum + course.credits, 0);
    const percent = totalCredits ? Math.round((completeCredits / totalCredits) * 100) : 0;
    const remaining = roadmap.filter(course => !state.completed.includes(course.code)).length;
    const available = roadmap.find(course => courseStatus(course) === "available");
    const terms = new Map();
    for (const course of roadmap) {
      const term = course.roadmapSemester;
      if (!terms.has(term)) terms.set(term, []);
      terms.get(term).push(course);
    }
    const termMarkup = [...terms.entries()].sort((a, b) => a[0] - b[0]).map(([semester, courses]) =>
      `<section><div class="roadmap-term-header"><h3>Semester ${semester}${semester === state.profile.semester ? " · Current" : ""}</h3><span>${courses.filter(course => state.completed.includes(course.code)).length} / ${courses.length} complete</span></div><div class="term-courses">${courses.map(courseCard).join("")}</div></section>`
    ).join("");
    const careerPlanMarkup = YEAR_ROADMAP.map(year => `<article class="career-year-card"><div class="career-year-heading"><span class="meta">YEAR ${year.year}</span><h3>${escapeHtml(year.title)}</h3></div><ul class="task-list">${year.tasks.map((task, index) => {
      const taskId = `year-${year.year}-${index + 1}`;
      const checked = state.roadmapTasks.includes(taskId);
      return `<li><label class="task-item"><input type="checkbox" data-action="toggle-roadmap-task" data-code="${taskId}" ${checked ? "checked" : ""}><span>${escapeHtml(task)}</span></label></li>`;
    }).join("")}</ul></article>`).join("");
    const content = `<div class="page-heading"><div><p class="eyebrow">ACADEMIC PLAN</p><h1>Your roadmap</h1><p>${escapeHtml(state.profile.branch)} · Semester ${state.profile.semester} · ${escapeHtml(state.profile.goal)}</p></div><button class="button button-secondary" type="button" data-action="edit-profile">Edit profile</button></div>
      <section class="overview-grid" aria-label="Progress overview">
        <div class="stat-card"><div class="stat-label">Credits completed</div><div class="stat-value">${completeCredits}<span style="color:var(--muted);font-size:14px"> / ${totalCredits}</span></div><div class="stat-note">Across recommended courses</div></div>
        <div class="stat-card"><div class="stat-label">Roadmap complete</div><div class="stat-value">${percent}%</div><div class="stat-note">By credits completed</div></div>
        <div class="stat-card"><div class="stat-label">Courses remaining</div><div class="stat-value">${remaining}</div><div class="stat-note">Completed courses excluded</div></div>
        <div class="stat-card"><div class="stat-label">Available now</div><div class="stat-value">${roadmap.filter(course => courseStatus(course) === "available").length}</div><div class="stat-note">Prerequisites are complete</div></div>
      </section>
      ${streakMarkup()}
      <div class="dashboard-grid">
        <section class="panel"><div class="panel-header"><h2>Semester-by-semester plan</h2><a class="panel-link" href="#/catalog">Browse catalog →</a></div><div class="panel-body"><div class="roadmap">${termMarkup || '<div class="empty-state"><h2>No courses found</h2><p>Update your profile to generate a roadmap.</p></div>'}</div></div></section>
        <aside class="panel"><div class="panel-header"><h2>Progress</h2><span class="meta">${percent}%</span></div><div class="panel-body">
          <div class="progress-track" role="progressbar" aria-label="Course progress" aria-valuenow="${percent}" aria-valuemin="0" aria-valuemax="100"><div class="progress-fill" style="width:${percent}%"></div></div>
          <div class="progress-row"><span>Credits completed</span><strong>${completeCredits} / ${totalCredits}</strong></div>
          <div class="progress-row"><span>Courses completed</span><strong>${roadmap.length - remaining} / ${roadmap.length}</strong></div>
          <div class="progress-graph-card glass-panel"><div class="progress-graph-heading"><span class="meta">CREDITS OVER TIME</span><span class="chart-legend"><i aria-hidden="true"></i>Completed</span></div>${progressChartMarkup(totalCredits)}</div>
          <div class="goal-block"><div class="meta">CAREER TARGET</div><p>${escapeHtml(state.profile.goal)}</p><div class="meta" style="margin-top:12px">CODING LEVEL / ${escapeHtml(state.profile.coding)}</div><p class="goal-guidance">${escapeHtml(codingGuidance())}</p></div>
          <div class="next-course"><div class="meta">NEXT AVAILABLE COURSE</div>${available ? `<h3 class="next-course-title">${escapeHtml(available.name)}</h3><p>${escapeHtml(available.code)} · ${available.credits} credits</p><div style="margin-top:10px"><button class="button button-primary small-button" type="button" data-action="enroll" data-code="${available.code}">Enroll</button></div>` : `<p class="next-course-title">No courses available</p><p>Complete an enrolled course to unlock the next step.</p>`}</div>
        </div></aside>
      </div>
      <section class="panel career-roadmap-panel"><div class="panel-header"><div><h2>Four-year career plan</h2><p class="panel-subtitle">A flexible checklist adapted from the provided B.Tech roadmap. Adjust it to your institution and goals.</p></div></div><div class="career-year-grid">${careerPlanMarkup}</div></section>`;
    shell(content, "dashboard");
  }

  function catalog() {
    const courses = getRoadmap();
    const semesters = [...new Set(courses.map(course => course.roadmapSemester))].sort((a, b) => a - b);
    const content = `<div class="page-heading"><div><p class="eyebrow">COURSE DIRECTORY</p><h1>Course catalog</h1><p>Search your recommended courses and check prerequisite status before enrolling.</p></div></div>
      <section class="panel">
        <div class="filters">
          <input class="field-control" id="course-search" type="search" placeholder="Search name, code, keyword" aria-label="Search courses">
          <select class="field-control" id="semester-filter" aria-label="Filter by semester"><option value="">All semesters</option>${semesters.map(semester => `<option value="${semester}">Semester ${semester}</option>`).join("")}</select>
          <select class="field-control" id="difficulty-filter" aria-label="Filter by difficulty"><option value="">All difficulties</option><option>Introductory</option><option>Intermediate</option><option>Advanced</option></select>
          <select class="field-control" id="status-filter" aria-label="Filter by status"><option value="">All statuses</option><option value="completed">Completed</option><option value="progress">In progress</option><option value="available">Available</option><option value="locked">Locked</option></select>
        </div>
        <div class="catalog-summary" id="catalog-summary">${courses.length} recommended courses</div>
        <div class="catalog-grid" id="catalog-grid">${courses.map(courseCard).join("")}</div>
      </section>`;
    shell(content, "catalog");
    const search = document.getElementById("course-search");
    const semester = document.getElementById("semester-filter");
    const difficulty = document.getElementById("difficulty-filter");
    const status = document.getElementById("status-filter");
    const renderFiltered = () => {
      const query = search.value.trim().toLowerCase();
      const filtered = courses.filter(course => {
        const searchable = `${course.name} ${course.code} ${course.description} ${course.keywords.join(" ")}`.toLowerCase();
        return (!query || searchable.includes(query)) &&
          (!semester.value || course.roadmapSemester === Number(semester.value)) &&
          (!difficulty.value || course.difficulty === difficulty.value) &&
          (!status.value || courseStatus(course) === status.value);
      });
      document.getElementById("catalog-summary").textContent = `${filtered.length} of ${courses.length} recommended courses`;
      document.getElementById("catalog-grid").innerHTML = filtered.length ? filtered.map(courseCard).join("") : `<div class="empty-state"><h2>No matching courses</h2><p>Change or clear your filters and try again.</p></div>`;
    };
    [search, semester, difficulty, status].forEach(field => field.addEventListener("input", renderFiltered));
  }

  function courseDetail(code) {
    const course = getRoadmap().find(item => item.code === code);
    if (!course) {
      go("catalog");
      showToast("That course is not in your current roadmap.");
      return;
    }
    const status = courseStatus(course);
    const prereqMarkup = course.prerequisites.length
      ? course.prerequisites.map(prereq => `<span class="prereq-chip">${escapeHtml(prereq)} · ${state.completed.includes(prereq) ? "Complete" : "Incomplete"}</span>`).join("")
      : `<span class="prereq-chip">No prerequisites</span>`;
    const content = `<div class="page-heading"><div><p class="eyebrow">COURSE DETAILS</p><h1>Course overview</h1><p>Review the course requirements and current enrollment status.</p></div><a class="button button-secondary" href="#/catalog">Back to catalog</a></div>
      <article class="detail-card">
        <div class="detail-top"><div><div class="course-code">${escapeHtml(course.code)}</div><h2 class="detail-title">${escapeHtml(course.name)}</h2><p class="detail-description">${escapeHtml(course.description)}</p></div>${statusMarkup(status)}</div>
        <div class="detail-facts"><div class="detail-fact"><div class="meta">Credits</div><strong>${course.credits}</strong></div><div class="detail-fact"><div class="meta">Recommended</div><strong>Semester ${course.roadmapSemester}</strong></div><div class="detail-fact"><div class="meta">Difficulty</div><strong>${escapeHtml(course.difficulty)}</strong></div></div>
        <section class="detail-section"><h3>Prerequisites</h3><div class="prereq-list">${prereqMarkup}</div>${status === "locked" ? `<p class="lock-note" style="margin-top:8px">Prerequisites not met. Complete the listed courses to unlock enrollment.</p>` : ""}</section>
        <section class="detail-section"><h3>Course keywords</h3><div class="prereq-list">${course.keywords.map(keyword => `<span class="prereq-chip">${escapeHtml(keyword)}</span>`).join("")}</div></section>
        <div class="detail-actions">${courseActions(course, status)}</div>
      </article>`;
    shell(content, "course");
  }

  function editProfilePage() {
    const content = `<div class="page-heading"><div><p class="eyebrow">PROFILE SETTINGS</p><h1>Edit profile</h1><p>Change these details to recalculate your recommended course sequence. Local demo email: ${escapeHtml(state.email)}.</p></div></div>
      <form class="detail-card" id="profile-form" novalidate>
        <div class="form-grid">
          <div class="form-field"><label for="branch">Engineering branch</label><select class="field-control" id="branch" name="branch" required>${BRANCHES.map(branch => `<option ${branch === state.profile.branch ? "selected" : ""}>${escapeHtml(branch)}</option>`).join("")}</select></div>
          <div class="form-field"><label for="semester">Current semester</label><select class="field-control" id="semester" name="semester" required>${Array.from({ length: 8 }, (_, index) => `<option value="${index + 1}" ${index + 1 === state.profile.semester ? "selected" : ""}>Semester ${index + 1}</option>`).join("")}</select></div>
          <div class="form-field"><label for="coding">Prior coding knowledge</label><select class="field-control" id="coding" name="coding" required>${["None", "Beginner", "Intermediate"].map(level => `<option ${level === state.profile.coding ? "selected" : ""}>${level}</option>`).join("")}</select></div>
          <div class="form-field"><label for="goal">Career target</label><select class="field-control" id="goal" name="goal" required>${CAREERS.map(goal => `<option ${goal === state.profile.goal ? "selected" : ""}>${escapeHtml(goal)}</option>`).join("")}</select></div>
        </div>
        <p class="form-error" id="form-error" role="alert"></p>
        <div class="detail-actions"><button class="button button-primary" type="submit">Save changes</button><button class="button button-secondary" type="button" data-action="reset-progress">Clear progress</button><button class="button button-quiet" type="button" data-action="sign-out">Sign out</button></div>
      </form>`;
    shell(content, "edit-profile");
    document.getElementById("profile-form").addEventListener("submit", async event => {
      event.preventDefault();
      const formData = new FormData(event.currentTarget);
      const next = { branch: String(formData.get("branch")), semester: Number(formData.get("semester")), coding: String(formData.get("coding")), goal: String(formData.get("goal")) };
      if (!BRANCHES.includes(next.branch) || !Number.isInteger(next.semester) || next.semester < 1 || next.semester > 8 || !["None", "Beginner", "Intermediate"].includes(next.coding) || !CAREERS.includes(next.goal)) {
        const error = document.getElementById("form-error");
        error.textContent = "Choose a valid value for each field.";
        error.classList.add("visible");
        return;
      }
      const roadmapChanged = state.profile.branch !== next.branch ||
        state.profile.semester !== next.semester || state.profile.goal !== next.goal;
      state.profile = next;
      const includedCodes = new Set(getCoursesForProfile().map(course => course.code));
      state.completed = state.completed.filter(code => includedCodes.has(code));
      state.enrolled = state.enrolled.filter(code => includedCodes.has(code));
      if (roadmapChanged) state.progressHistory = [];
      recordProgressSnapshot();
      if (!await saveState()) return;
      showToast("Profile and roadmap updated.");
      go("dashboard");
    });
  }

  function profilePage() {
    const projectEntries = state.resume.projects.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    const fullName = state.resume.fullName || "Student";
    const initials = fullName.split(/\s+/).filter(Boolean).map(part => part[0]).slice(0, 2).join("").toUpperCase();
    const about = state.resume.summary || "Add a short professional summary in Resume Prep.";
    const content = `<div class="page-heading"><div><p class="eyebrow">STUDENT PROFILE</p><h1>My profile</h1><p>Your local academic and career profile. It is not published or shared outside this browser.</p></div><div class="heading-actions"><button class="button button-secondary" type="button" data-action="copy-profile">Copy summary</button><a class="button button-secondary" href="#/edit-profile">Edit profile</a><a class="button button-primary" href="#/resume">Resume prep</a></div></div>
      <section class="profile-overview panel">
        <div class="profile-identity"><span class="avatar profile-avatar" aria-hidden="true">${escapeHtml(initials || "S")}</span><div><h2>${escapeHtml(fullName)}</h2><p>${escapeHtml(state.profile.branch)} · Semester ${state.profile.semester} · ${escapeHtml(state.profile.goal)}</p><span class="meta">${escapeHtml(state.email)}</span></div></div>
        <div class="profile-counts"><div><span class="meta">RESUME</span><strong>${state.resume.fullName || state.resume.summary ? "Draft saved" : "Not started"}</strong></div><div><span class="meta">ENROLLED COURSES</span><strong>${state.enrolled.length}</strong></div><div><span class="meta">PROJECTS</span><strong>${projectEntries.length}</strong></div></div>
      </section>
      <div class="profile-content-grid">
        <section class="panel"><div class="panel-header"><h2>About</h2></div><div class="panel-body"><p class="profile-copy">${escapeHtml(about)}</p><div class="profile-facts"><div><span class="meta">CAREER TARGET</span><strong>${escapeHtml(state.profile.goal)}</strong></div><div><span class="meta">CODING EXPERIENCE</span><strong>${escapeHtml(state.profile.coding)}</strong></div><div><span class="meta">LOCATION</span><strong>${escapeHtml(state.resume.location || "Not added")}</strong></div></div></div></section>
        <section class="panel"><div class="panel-header"><h2>Experience</h2></div><div class="panel-body"><p class="profile-copy">${escapeHtml(state.resume.experience || "Add internships, work, or relevant activities in Resume Prep.")}</p></div></section>
        <section class="panel"><div class="panel-header"><h2>Proof of work</h2><a class="panel-link" href="#/resume">Edit resume</a></div><div class="panel-body">${projectEntries.length ? `<ul class="plain-list">${projectEntries.map(entry => `<li>${escapeHtml(entry)}</li>`).join("")}</ul>` : `<p class="profile-copy">Add project names and links in Resume Prep to document your work.</p>`}${state.resume.links ? `<div class="profile-links">${state.resume.links.split(/\r?\n/).filter(Boolean).map(link => `<p>${escapeHtml(link.trim())}</p>`).join("")}</div>` : ""}</div></section>
      </div>`;
    shell(content, "profile");
  }

  function mockTestPage() {
    const active = state.activeTest;
    if (active) {
      const quiz = MOCK_TESTS.find(test => test.id === active.quizId);
      if (!quiz || !Number.isInteger(active.index) || active.index < 0 || active.index >= quiz.questions.length) {
        shell(`<div class="page-heading"><div><p class="eyebrow">MOCK TEST</p><h1>Practice session unavailable</h1><p>The saved session does not match the current question set.</p></div></div><button class="button button-secondary" type="button" data-action="exit-mock-test">Return to mock tests</button>`, "mock-test");
        return;
      }
      const question = quiz.questions[active.index];
      const checked = Boolean(active.checked);
      const selectedAnswer = Number.isInteger(active.selectedAnswer) ? active.selectedAnswer : -1;
      const feedback = checked
        ? `<div class="answer-feedback"><strong>${selectedAnswer === question.answer ? "Correct" : "Review this answer"}</strong><p>${escapeHtml(question.explanation)}</p></div>`
        : "";
      const content = `<div class="page-heading"><div><p class="eyebrow">${escapeHtml(quiz.title)} / ${escapeHtml(quiz.coverage)}</p><h1>Question ${active.index + 1} of ${quiz.questions.length}</h1><p>Practice check only. This is not an official university paper.</p></div><button class="button button-secondary" type="button" data-action="exit-mock-test">Exit test</button></div>
        <section class="detail-card quiz-card"><div class="quiz-progress-track" role="progressbar" aria-label="Test question progress" aria-valuenow="${active.index + 1}" aria-valuemin="0" aria-valuemax="${quiz.questions.length}"><span style="width:${((active.index + 1) / quiz.questions.length) * 100}%"></span></div><form id="mock-answer-form"><fieldset class="quiz-fieldset"><legend>${escapeHtml(question.prompt)}</legend>${question.choices.map((choice, index) => `<label class="quiz-choice"><input type="radio" name="answer" value="${index}" ${selectedAnswer === index ? "checked" : ""} ${checked ? "disabled" : ""} required><span>${escapeHtml(choice)}</span></label>`).join("")}</fieldset>${feedback}${checked ? `<button class="button button-primary" type="button" data-action="next-mock-question">${active.index + 1 === quiz.questions.length ? "Finish test" : "Next question"}</button>` : `<button class="button button-primary" type="submit">Check answer</button>`}</form></section>`;
      shell(content, "mock-test");
      document.getElementById("mock-answer-form").addEventListener("submit", async event => {
        event.preventDefault();
        const answer = new FormData(event.currentTarget).get("answer");
        if (answer === null || !state.activeTest) return;
        state.activeTest.selectedAnswer = Number(answer);
        if (!Array.isArray(state.activeTest.answers)) state.activeTest.answers = [];
        state.activeTest.answers[active.index] = Number(answer);
        state.activeTest.checked = true;
        if (!await saveState()) {
          render();
          return;
        }
        render();
      });
      return;
    }

    const history = state.mockTestResults.slice().reverse().slice(0, 5);
    const renderTests = () => {
      const filtered = MOCK_TESTS.filter(test => {
        const searchable = `${test.title} ${test.coverage} first-year engineering programming mathematics physics chemistry`.toLowerCase();
        return (!mockTestSearchQuery || searchable.includes(mockTestSearchQuery)) &&
          (!mockTestSectionFilter || test.examType === mockTestSectionFilter);
      });
      const cards = filtered.map(test => {
        const latest = state.mockTestResults.filter(result => result.quizId === test.id).slice(-1)[0];
        return `<article class="tool-card"><div class="tool-card-heading"><div><span class="meta">${escapeHtml(test.coverage)}</span><h2>${escapeHtml(test.title)}</h2></div><span class="course-code">${test.questions.length} QUESTIONS</span></div><p>First-year engineering topics with immediate explanations after each answer.</p><div class="tool-card-actions"><button class="button button-primary small-button" type="button" data-action="start-mock-test" data-code="${test.id}">Start test</button>${latest ? `<span class="meta">Last score: ${latest.score} / ${latest.total}</span>` : ""}</div></article>`;
      }).join("");
      document.getElementById("mock-test-grid").innerHTML = cards || `<div class="empty-state"><h2>No matching tests</h2><p>Change or clear your search and filter.</p></div>`;
      document.getElementById("mock-test-summary").textContent = `${filtered.length} of ${MOCK_TESTS.length} tests`;
    };
    const historyMarkup = history.length ? `<div class="table-wrap"><table class="data-table"><thead><tr><th>Test</th><th>Score</th><th>Completed</th></tr></thead><tbody>${history.map(result => {
      const test = MOCK_TESTS.find(item => item.id === result.quizId);
      return `<tr><td>${escapeHtml(test ? test.title : "Mock test")}</td><td>${result.score} / ${result.total}</td><td>${escapeHtml(new Date(result.completedAt).toLocaleDateString())}</td></tr>`;
    }).join("")}</tbody></table></div>` : `<p class="profile-copy">Completed tests will appear here after you submit one.</p>`;
    const content = `<div class="page-heading"><div><p class="eyebrow">PRACTICE</p><h1>Mock tests</h1><p>Short multiple-choice checks based on common first-year engineering topics. Scores stay in this browser.</p></div></div>
      <section class="panel test-catalog"><div class="filters test-filters"><input class="field-control" id="mock-test-search" type="search" placeholder="Search tests or topics" aria-label="Search mock tests"><select class="field-control" id="mock-test-section" aria-label="Filter by exam type"><option value="">All exam types</option><option value="midterm">Midterms</option><option value="semester-end">Semester-end</option></select></div><div class="catalog-summary" id="mock-test-summary"></div><div class="tool-grid compact-tool-grid" id="mock-test-grid"></div></section>
      <section class="panel"><div class="panel-header"><h2>Recent results</h2></div><div class="panel-body">${historyMarkup}</div></section>`;
    shell(content, "mock-test");
    const search = document.getElementById("mock-test-search");
    const section = document.getElementById("mock-test-section");
    search.value = mockTestSearchQuery;
    section.value = mockTestSectionFilter;
    search.addEventListener("input", () => {
      mockTestSearchQuery = search.value.trim().toLowerCase();
      renderTests();
    });
    section.addEventListener("change", () => {
      mockTestSectionFilter = section.value;
      renderTests();
    });
    renderTests();
  }

  function interviewPrepPage() {
    const practiced = new Set(state.practicedQuestions);
    const questionCards = INTERVIEW_TOPICS.flatMap(topic => topic.questions.map((entry, index) => {
      const id = `${topic.id}-${index + 1}`;
      const searchable = `${topic.title} ${entry[0]} ${entry[1]}`.toLowerCase();
      return { id, title: topic.title, question: entry[0], guidance: entry[1], searchable };
    }));
    const renderQuestions = query => {
      const filtered = questionCards.filter(item => !query || item.searchable.includes(query));
      document.getElementById("interview-question-list").innerHTML = filtered.length ? filtered.map(item => `<article class="question-card"><div class="question-meta"><span class="meta">${escapeHtml(item.title)}</span><button class="text-button practice-toggle" type="button" data-action="toggle-practiced" data-code="${item.id}">${practiced.has(item.id) ? "Practiced" : "Mark practiced"}</button></div><h3>${escapeHtml(item.question)}</h3><details><summary>Show answer outline</summary><p>${escapeHtml(item.guidance)}</p></details></article>`).join("") : `<div class="empty-state"><h2>No matching questions</h2><p>Try a different search term.</p></div>`;
      document.getElementById("interview-search-summary").textContent = `${filtered.length} questions shown · ${practiced.size} practiced`;
    };
    const content = `<div class="page-heading"><div><p class="eyebrow">PREPARATION</p><h1>Interview prep</h1><p>Review common technical and project discussion prompts. Mark a question when you have practiced an answer.</p></div></div>
      <section class="panel"><div class="filters single-filter"><input class="field-control" id="interview-search" type="search" placeholder="Search questions or topics" aria-label="Search interview questions"></div><div class="catalog-summary" id="interview-search-summary"></div><div class="question-list" id="interview-question-list"></div></section>`;
    shell(content, "interview-prep");
    renderQuestions(interviewSearchQuery);
    document.getElementById("interview-search").value = interviewSearchQuery;
    document.getElementById("interview-search").addEventListener("input", event => {
      interviewSearchQuery = event.currentTarget.value.trim().toLowerCase();
      renderQuestions(interviewSearchQuery);
    });
  }

  function resumePage() {
    const resume = state.resume;
    const preview = `<div class="resume-preview"><header><h2>${escapeHtml(resume.fullName || "Your name")}</h2><p>${escapeHtml(resume.headline || state.profile.goal)}</p><p>${escapeHtml([resume.location, state.email].filter(Boolean).join(" · "))}</p></header>${[
      ["Summary", resume.summary], ["Education", resume.education], ["Skills", resume.skills],
      ["Experience", resume.experience], ["Projects", resume.projects], ["Links", resume.links]
    ].filter(section => section[1]).map(section => `<section><h3>${escapeHtml(section[0])}</h3><p>${escapeHtml(section[1])}</p></section>`).join("")}</div>`;
    const content = `<div class="page-heading"><div><p class="eyebrow">CAREER MATERIALS</p><h1>Resume prep</h1><p>Draft a resume from your own details. Your information stays in this browser until you export it.</p></div><button class="button button-secondary" type="button" data-action="download-resume">Download .txt</button></div>
      <div class="resume-grid"><form class="detail-card resume-form" id="resume-form">
        <div class="form-grid">
          <div class="form-field"><label for="resume-name">Full name</label><input class="field-control" id="resume-name" name="fullName" maxlength="120" value="${escapeHtml(resume.fullName)}"></div>
          <div class="form-field"><label for="resume-headline">Target role or headline</label><input class="field-control" id="resume-headline" name="headline" maxlength="160" value="${escapeHtml(resume.headline)}"></div>
          <div class="form-field"><label for="resume-location">Location</label><input class="field-control" id="resume-location" name="location" maxlength="120" value="${escapeHtml(resume.location)}"></div>
          <div class="form-field"><label for="resume-skills">Skills</label><textarea class="field-control" id="resume-skills" name="skills" rows="3" maxlength="2000" placeholder="Separate skills with commas">${escapeHtml(resume.skills)}</textarea></div>
          <div class="form-field full-field"><label for="resume-summary">Summary</label><textarea class="field-control" id="resume-summary" name="summary" rows="4" maxlength="2000">${escapeHtml(resume.summary)}</textarea></div>
          <div class="form-field full-field"><label for="resume-education">Education</label><textarea class="field-control" id="resume-education" name="education" rows="3" maxlength="2000" placeholder="Degree, institution, dates, relevant coursework">${escapeHtml(resume.education)}</textarea></div>
          <div class="form-field full-field"><label for="resume-experience">Experience</label><textarea class="field-control" id="resume-experience" name="experience" rows="4" maxlength="3000">${escapeHtml(resume.experience)}</textarea></div>
          <div class="form-field full-field"><label for="resume-projects">Projects / proof of work</label><textarea class="field-control" id="resume-projects" name="projects" rows="4" maxlength="3000" placeholder="One project per line">${escapeHtml(resume.projects)}</textarea></div>
          <div class="form-field full-field"><label for="resume-links">Portfolio and professional links</label><textarea class="field-control" id="resume-links" name="links" rows="3" maxlength="2000" placeholder="One link per line">${escapeHtml(resume.links)}</textarea></div>
        </div>
        <div class="detail-actions"><button class="button button-primary" type="submit">Save resume details</button></div>
      </form><section class="panel resume-preview-panel"><div class="panel-header"><h2>Preview</h2></div><div class="panel-body">${preview}</div></section></div>`;
    shell(content, "resume");
    document.getElementById("resume-form").addEventListener("submit", async event => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      for (const key of Object.keys(state.resume)) state.resume[key] = String(data.get(key) || "").trim();
      recordActivity();
      if (!await saveState()) return;
      showToast("Resume details saved in this browser.");
      render();
    });
  }

  function interviewPromptsForRole(role) {
    const lower = role.toLowerCase();
    let order = ["programming", "dsa", "systems", "projects"];
    if (lower.includes("data") || lower.includes("ai") || lower.includes("cyber")) order = ["dsa", "systems", "programming", "projects"];
    if (lower.includes("embedded") || lower.includes("power") || lower.includes("mechanical") || lower.includes("structural")) order = ["systems", "programming", "dsa", "projects"];
    return order.flatMap(id => {
      const topic = INTERVIEW_TOPICS.find(item => item.id === id);
      return topic.questions.slice(0, 2).map(question => ({ topic: topic.title, prompt: question[0] }));
    });
  }

  function mockInterviewPage() {
    const active = state.mockInterview;
    if (active) {
      const prompts = interviewPromptsForRole(active.role).slice(0, active.questionCount);
      if (!prompts.length || !Number.isInteger(active.index) || active.index < 0 || active.index >= prompts.length) {
        shell(`<div class="page-heading"><div><p class="eyebrow">PRACTICE SESSION</p><h1>Session unavailable</h1><p>The saved session details are incomplete.</p></div></div><button class="button button-secondary" type="button" data-action="exit-mock-interview">Return to mock interview</button>`, "mock-interview");
        return;
      }
      const question = prompts[active.index];
      const answer = Array.isArray(active.answers) ? String(active.answers[active.index] || "") : "";
      const content = `<div class="page-heading"><div><p class="eyebrow">${escapeHtml(active.role)} / ${escapeHtml(active.format)}</p><h1>Question ${active.index + 1} of ${prompts.length}</h1><p>${escapeHtml(question.topic)}</p></div><button class="button button-secondary" type="button" data-action="exit-mock-interview">Save and exit</button></div>
        <section class="detail-card interview-session-card"><h2>${escapeHtml(question.prompt)}</h2><p class="profile-copy">Write a response or outline your answer. This local practice session does not record audio or video.</p><form id="mock-interview-answer"><div class="form-field"><label for="interview-answer">Your response / notes</label><textarea class="field-control" id="interview-answer" name="answer" rows="8" maxlength="5000">${escapeHtml(answer)}</textarea></div><div class="detail-actions"><button class="button button-primary" type="submit">${active.index + 1 === prompts.length ? "Finish session" : "Save answer and continue"}</button></div></form></section>`;
      shell(content, "mock-interview");
      document.getElementById("interview-answer").addEventListener("change", async event => {
        if (!state.mockInterview) return;
        if (!Array.isArray(state.mockInterview.answers)) state.mockInterview.answers = [];
        state.mockInterview.answers[active.index] = event.currentTarget.value;
        if (!await saveState()) render();
      });
      document.getElementById("mock-interview-answer").addEventListener("submit", async event => {
        event.preventDefault();
        const response = String(new FormData(event.currentTarget).get("answer") || "").trim();
        if (!Array.isArray(state.mockInterview.answers)) state.mockInterview.answers = [];
        state.mockInterview.answers[active.index] = response;
        if (response) recordActivity();
        if (active.index + 1 < prompts.length) {
          state.mockInterview.index += 1;
          if (!await saveState()) {
            render();
            return;
          }
          render();
          return;
        }
        state.interviewSessions.push({
          role: active.role, format: active.format, completed: true, completedAt: new Date().toISOString(),
          answers: prompts.map((item, index) => ({ prompt: item.prompt, response: state.mockInterview.answers[index] || "" }))
        });
        state.mockInterview = null;
        if (!await saveState()) {
          render();
          return;
        }
        showToast("Mock interview saved.");
        render();
      });
      return;
    }

    const history = state.interviewSessions.slice().reverse().slice(0, 5);
    const historyMarkup = history.length ? history.map(session => `<details class="session-history"><summary>${escapeHtml(session.role)} · ${escapeHtml(session.format || "Practice")} · ${session.completed ? "Completed" : "Saved"} · ${escapeHtml(new Date(session.completedAt).toLocaleDateString())}</summary><div>${(Array.isArray(session.answers) ? session.answers : []).map(item => `<div class="history-answer"><strong>${escapeHtml(item.prompt || "")}</strong><p>${escapeHtml(item.response || "No notes saved.")}</p></div>`).join("")}</div></details>`).join("") : `<p class="profile-copy">Completed or saved practice sessions will appear here.</p>`;
    const content = `<div class="page-heading"><div><p class="eyebrow">PRACTICE SESSION</p><h1>Mock interview</h1><p>Work through role-relevant prompts and save written answers for review. No audio or video is recorded.</p></div></div>
      <section class="detail-card mock-interview-start"><h2>Start a session</h2><form id="mock-interview-start"><div class="form-grid"><div class="form-field"><label for="interview-role">Career target</label><select class="field-control" id="interview-role" name="role">${CAREERS.map(goal => `<option ${goal === state.profile.goal ? "selected" : ""}>${escapeHtml(goal)}</option>`).join("")}</select></div><div class="form-field"><label for="interview-format">Session format</label><select class="field-control" id="interview-format" name="format"><option value="Guided · 4 questions">Guided · 4 questions</option><option value="Standard · 6 questions">Standard · 6 questions</option></select></div></div><div class="detail-actions"><button class="button button-primary" type="submit">Start mock interview</button></div></form></section>
      <section class="panel"><div class="panel-header"><h2>Recent sessions</h2></div><div class="panel-body">${historyMarkup}</div></section>`;
    shell(content, "mock-interview");
    document.getElementById("mock-interview-start").addEventListener("submit", async event => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const format = String(data.get("format") || "");
      state.mockInterview = {
        role: String(data.get("role") || ""), format,
        questionCount: format.startsWith("Guided") ? 4 : 6,
        index: 0, answers: []
      };
      if (!await saveState()) return;
      render();
    });
  }

  function assessmentSummary(record) {
    if (!record || typeof record !== "object") return null;
    const values = ["mid1", "mid2", "assignment1", "assignment2", "viva", "see"].map(key => Number(record[key]));
    const maxima = [30, 30, 5, 5, 5, 60];
    if (values.some((value, index) => !Number.isFinite(value) || value < 0 || value > maxima[index])) return null;
    const cie = (values[0] + values[1]) / 2 + (values[2] + values[3]) / 2 + values[4];
    const total = cie + values[5];
    return { cie, see: values[5], total, passed: values[5] >= 21 && total >= 40 };
  }

  function assessmentStatusMarkup(result) {
    if (!result) return `<span class="status status-available"><span class="status-dot" aria-hidden="true"></span>Marks not entered</span>`;
    return `<span class="status status-${result.passed ? "completed" : "progress"}"><span class="status-dot" aria-hidden="true"></span>${result.passed ? "Meets example threshold" : "Review required"}</span>`;
  }

  function labAssessmentSummary(record) {
    if (!record || typeof record !== "object") return null;
    const keys = ["record", "internalTest", "vivaProject", "writeup", "execution", "analysis", "externalViva"];
    const maxima = [15, 15, 10, 10, 30, 10, 10];
    const values = keys.map(key => Number(record[key]));
    if (values.some((value, index) => !Number.isFinite(value) || value < 0 || value > maxima[index])) return null;
    const internal = values.slice(0, 3).reduce((sum, value) => sum + value, 0);
    const external = values.slice(3).reduce((sum, value) => sum + value, 0);
    return { internal, external, total: internal + external };
  }

  function assessmentPage() {
    const semesters = [1, 2];
    const semesterForms = semesters.map(semester => {
      const record = state.assessmentMarks[String(semester)] || {};
      const result = assessmentSummary(record);
      const fields = [
        ["mid1", "Mid-I", 30], ["mid2", "Mid-II", 30], ["assignment1", "Assignment 1", 5],
        ["assignment2", "Assignment 2", 5], ["viva", "Viva / presentation", 5], ["see", "Semester-end exam", 60]
      ];
      const fieldsMarkup = fields.map(([key, label, maximum]) => `<div class="form-field"><label for="sem${semester}-${key}">${label} / ${maximum}</label><input class="field-control" id="sem${semester}-${key}" name="${key}" type="number" min="0" max="${maximum}" step="0.5" value="${record[key] === undefined ? "" : escapeHtml(record[key])}" required></div>`).join("");
      return `<form class="detail-card marks-form" id="assessment-semester-${semester}" data-semester="${semester}"><div class="marks-heading"><div><p class="eyebrow">SEMESTER ${semester}</p><h2>Assessment record</h2></div>${assessmentStatusMarkup(result)}</div><div class="form-grid">${fieldsMarkup}</div>${result ? `<div class="score-summary"><div><span class="meta">CIE / 40</span><strong>${result.cie.toFixed(1)}</strong></div><div><span class="meta">SEE / 60</span><strong>${result.see}</strong></div><div><span class="meta">TOTAL / 100</span><strong>${result.total.toFixed(1)}</strong></div></div><p class="form-hint">${result.passed ? "Meets the example pass thresholds shown below." : "Does not meet one or both example pass thresholds shown below."}</p>` : `<p class="form-hint">Enter all marks to calculate a result.</p>`}<div class="detail-actions"><button class="button button-primary" type="submit">Save marks</button></div></form>`;
    }).join("");
    const labForms = semesters.map(semester => {
      const record = state.labMarks[String(semester)] || {};
      const result = labAssessmentSummary(record);
      const fields = [
        ["record", "Record / observation", 15], ["internalTest", "Internal test", 15], ["vivaProject", "Viva / mini-project", 10],
        ["writeup", "External write-up", 10], ["execution", "Execution / code", 30], ["analysis", "Result analysis", 10],
        ["externalViva", "External viva", 10]
      ];
      const fieldsMarkup = fields.map(([key, label, maximum]) => `<div class="form-field"><label for="lab${semester}-${key}">${label} / ${maximum}</label><input class="field-control" id="lab${semester}-${key}" name="${key}" type="number" min="0" max="${maximum}" step="0.5" value="${record[key] === undefined ? "" : escapeHtml(record[key])}" required></div>`).join("");
      return `<form class="detail-card marks-form" id="assessment-lab-${semester}"><div class="marks-heading"><div><p class="eyebrow">SEMESTER ${semester} / LAB</p><h2>Laboratory record</h2></div><span class="status status-${result ? "completed" : "available"}"><span class="status-dot" aria-hidden="true"></span>${result ? "Marks saved" : "Marks not entered"}</span></div><div class="form-grid">${fieldsMarkup}</div>${result ? `<div class="score-summary"><div><span class="meta">INTERNAL / 40</span><strong>${result.internal}</strong></div><div><span class="meta">EXTERNAL / 60</span><strong>${result.external}</strong></div><div><span class="meta">TOTAL / 100</span><strong>${result.total}</strong></div></div>` : `<p class="form-hint">Enter all marks to calculate totals. No lab pass threshold is assumed.</p>`}<div class="detail-actions"><button class="button button-primary" type="submit">Save lab marks</button></div></form>`;
    }).join("");
    const content = `<div class="page-heading"><div><p class="eyebrow">ACADEMIC RECORD</p><h1>Assessment</h1><p>Enter first-year marks to track your own results against the pattern in the provided reference.</p></div></div>
      <div class="notice-panel"><strong>Example pattern, not a universal rule.</strong><p>Institutions and regulations differ. Confirm your official scheme, weighting, and pass criteria with your college.</p></div>
      <section class="panel exam-pattern"><div class="panel-header"><h2>Theory examination pattern</h2><span class="meta">REFERENCE SUMMARY</span></div><div class="panel-body"><div class="pattern-grid"><div><span class="meta">FIRST-YEAR SCHEDULE</span><p>Two semesters, two midterms per semester, and one semester-end exam per semester.</p></div><div><span class="meta">CONTINUOUS INTERNAL / 40</span><p>Midterms contribute 30 marks, assignments 5, and viva, presentation, or case study 5.</p></div><div><span class="meta">SEMESTER-END / 60</span><p>Three-hour paper covering all five units. The reference gives ten short answers and five long-answer questions with internal choice.</p></div><div><span class="meta">MIDTERM / 30</span><p>Two-hour paper. Part A: ten compulsory one-mark objective questions. Part B: six five-mark questions, answer any four. Mid-I typically covers Units 1-2; Mid-II covers Units 3-5.</p></div><div><span class="meta">EXAMPLE PASS THRESHOLD</span><p>At least 21/60 in the SEE and 40/100 overall, subject to your institution's rules.</p></div></div><p class="form-hint">This tracker calculates CIE as the average of Mid-I and Mid-II scores, plus the average of two assignment scores, plus viva marks. Check whether your institution uses this exact calculation.</p></div></section>
      <section class="panel lab-pattern"><div class="panel-header"><h2>Laboratory pattern</h2><span class="meta">REFERENCE SUMMARY</span></div><div class="panel-body pattern-grid"><div><span class="meta">INTERNAL / 40</span><p>Record and observation 15, internal test 15, viva or mini-project 10.</p></div><div><span class="meta">EXTERNAL / 60</span><p>Write-up 10, execution or code 30, result analysis 10, viva 10.</p></div></div></section>
      <section class="marks-grid">${semesterForms}</section>
      <section><div class="section-title subsection-heading">Laboratory marks</div><div class="marks-grid">${labForms}</div></section>
      <section class="panel"><div class="panel-header"><h2>Typical first-year subjects</h2></div><div class="panel-body"><p class="profile-copy">The reference describes a common pattern rather than a single national syllabus: Semester 1 includes matrices and calculus, physics or chemistry, C programming, graphics, basic electrical engineering, and laboratories. Semester 2 includes differential equations and vector calculus, applied physics or chemistry, data structures or Python, English, workshop, and laboratories.</p></div></section>`;
    shell(content, "assessment");
    semesters.forEach(semester => {
      document.getElementById(`assessment-semester-${semester}`).addEventListener("submit", async event => {
        event.preventDefault();
        const form = event.currentTarget;
        const data = new FormData(form);
        const row = {};
        const limits = { mid1: 30, mid2: 30, assignment1: 5, assignment2: 5, viva: 5, see: 60 };
        for (const [key, maximum] of Object.entries(limits)) {
          const value = Number(data.get(key));
          if (!Number.isFinite(value) || value < 0 || value > maximum) {
            showToast(`Enter a mark from 0 to ${maximum} for ${key}.`);
            return;
          }
          row[key] = value;
        }
        state.assessmentMarks[String(semester)] = row;
        recordActivity();
        if (!await saveState()) return;
        showToast(`Semester ${semester} marks saved.`);
        render();
      });
      document.getElementById(`assessment-lab-${semester}`).addEventListener("submit", async event => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        const limits = { record: 15, internalTest: 15, vivaProject: 10, writeup: 10, execution: 30, analysis: 10, externalViva: 10 };
        const row = {};
        for (const [key, maximum] of Object.entries(limits)) {
          const value = Number(data.get(key));
          if (!Number.isFinite(value) || value < 0 || value > maximum) {
            showToast(`Enter a mark from 0 to ${maximum} for ${key}.`);
            return;
          }
          row[key] = value;
        }
        state.labMarks[String(semester)] = row;
        recordActivity();
        if (!await saveState()) return;
        showToast(`Semester ${semester} lab marks saved.`);
        render();
      });
    });
  }

  function jobsPage() {
    const renderPaths = query => {
      const filtered = CAREER_PATHS.filter(path => `${path.title} ${path.audience} ${path.description}`.toLowerCase().includes(query));
      document.getElementById("job-path-list").innerHTML = filtered.length ? filtered.map(path => `<article class="tool-card job-card"><div class="tool-card-heading"><div><span class="meta">${escapeHtml(path.audience)}</span><h2>${escapeHtml(path.title)}</h2></div><button class="text-button" type="button" data-action="toggle-saved-job" data-code="${path.id}">${state.savedJobs.includes(path.id) ? "Saved" : "Save path"}</button></div><p>${escapeHtml(path.description)}</p><div class="resource-links">${path.links.map(link => `<a href="${link.url}" target="_blank" rel="noopener noreferrer">${escapeHtml(link.label)} <span aria-hidden="true">↗</span></a>`).join("")}</div></article>`).join("") : `<div class="empty-state"><h2>No matching pathways</h2><p>Try a broader search.</p></div>`;
      document.getElementById("job-search-summary").textContent = `${filtered.length} pathways · ${state.savedJobs.length} saved`;
    };
    const resourceMarkup = LEARNING_RESOURCES.map(resource => `<a class="resource-card" href="${resource.url}" target="_blank" rel="noopener noreferrer"><span class="meta">${escapeHtml(resource.type)}</span><strong>${escapeHtml(resource.label)} <span aria-hidden="true">↗</span></strong></a>`).join("");
    const content = `<div class="page-heading"><div><p class="eyebrow">CAREER ROUTES</p><h1>Jobs & pathways</h1><p>Explore career routes and external resources. Pathwise does not fetch or claim to list live vacancies.</p></div></div>
      <section class="notice-panel"><strong>Verify current requirements.</strong><p>Recruitment dates, eligibility, and examination rules change. Use the linked organization's official notices before applying.</p></section>
      <section class="panel"><div class="filters single-filter"><input class="field-control" id="job-search" type="search" placeholder="Search role or pathway" aria-label="Search career pathways"></div><div class="catalog-summary" id="job-search-summary"></div><div class="tool-grid compact-tool-grid" id="job-path-list"></div></section>
      <section class="panel"><div class="panel-header"><h2>Learning resources</h2></div><div class="resource-grid">${resourceMarkup}</div></section>`;
    shell(content, "jobs");
    renderPaths(jobSearchQuery);
    document.getElementById("job-search").value = jobSearchQuery;
    document.getElementById("job-search").addEventListener("input", event => {
      jobSearchQuery = event.currentTarget.value.trim().toLowerCase();
      renderPaths(jobSearchQuery);
    });
  }

  function settingsPage() {
    const content = `<div class="page-heading"><div><p class="eyebrow">PREFERENCES</p><h1>Settings</h1><p>Manage local data for this browser. There is no cloud sync or external account provider.</p></div></div>
      <section class="settings-list">
        <article class="panel settings-row"><div><h2>Export my data</h2><p>Download your profile, course progress, daily streak and progress-chart history, marks, practice history, and resume details as a JSON file.</p></div><button class="button button-secondary" type="button" data-action="export-data">Export JSON</button></article>
        <article class="panel settings-row"><div><h2>Clear learning data</h2><p>Remove course progress, streak and chart history, assessment marks, saved pathways, and practice history. Your sign-in, diagnostic profile, and resume remain.</p></div><button class="button button-secondary" type="button" data-action="clear-learning-data">Clear learning data</button></article>
        <article class="panel settings-row"><div><h2>Sign out</h2><p>Your saved data remains in this browser and is available the next time you sign in on this device.</p></div><button class="button button-secondary" type="button" data-action="sign-out">Sign out</button></article>
      </section>
      <div class="footer-inline"><a href="./privacy.html">Privacy policy</a><a href="./terms.html">Terms &amp; conditions</a></div>`;
    shell(content, "settings");
  }

  function downloadFile(filename, content, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function act(action, code) {
    const course = getRoadmap().find(item => item.code === code);
    if (action === "toggle-mobile-menu") {
      mobileMenuOpen = !mobileMenuOpen;
      render();
      return;
    }
    if (action === "google-signin") {
      showAuthFeedback("Google sign-in is not configured for this local demo. Use email and password.");
      return;
    }
    if (action === "forgot-password") {
      showAuthFeedback("Password recovery is not available. Saved data is encrypted and cannot be recovered without your password.");
      return;
    }
    if (action === "sign-out") {
      emailDraft = state.email || "";
      authMode = "login";
      if (!await saveState()) return;
      state.email = null;
      accountEncryptionKey = null;
      window.location.hash = "";
      render();
      return;
    }
    if (action === "back-dashboard") return go("dashboard");
    if (action === "edit-profile") return go("edit-profile");
    if (action === "reset-progress") {
      if (!window.confirm("Clear all completed and enrolled courses on this device? Your profile will remain.")) return;
      state.completed = [];
      state.enrolled = [];
      recordProgressSnapshot();
      if (!await saveState()) {
        render();
        return;
      }
      showToast("Course progress cleared.");
      go("dashboard");
      return;
    }
    if (action === "toggle-roadmap-task") {
      if (!state.roadmapTasks.includes(code)) recordActivity();
      state.roadmapTasks = state.roadmapTasks.includes(code)
        ? state.roadmapTasks.filter(task => task !== code)
        : [...state.roadmapTasks, code];
      if (!await saveState()) {
        render();
        return;
      }
      render();
      return;
    }
    if (action === "toggle-practiced") {
      if (!state.practicedQuestions.includes(code)) recordActivity();
      state.practicedQuestions = state.practicedQuestions.includes(code)
        ? state.practicedQuestions.filter(item => item !== code)
        : [...state.practicedQuestions, code];
      if (!await saveState()) {
        render();
        return;
      }
      render();
      return;
    }
    if (action === "toggle-saved-job") {
      state.savedJobs = state.savedJobs.includes(code)
        ? state.savedJobs.filter(item => item !== code)
        : [...state.savedJobs, code];
      if (!await saveState()) {
        render();
        return;
      }
      render();
      return;
    }
    if (action === "start-mock-test") {
      const quiz = MOCK_TESTS.find(test => test.id === code);
      if (!quiz) {
        showToast("That mock test is not available.");
        return;
      }
      state.activeTest = { quizId: quiz.id, index: 0, answers: [], checked: false };
      if (!await saveState()) return;
      render();
      return;
    }
    if (action === "next-mock-question") {
      const active = state.activeTest;
      const quiz = active && MOCK_TESTS.find(test => test.id === active.quizId);
      if (!active || !quiz || !active.checked) {
        showToast("Select and check an answer before continuing.");
        return;
      }
      if (active.index + 1 < quiz.questions.length) {
        active.index += 1;
        active.checked = false;
        delete active.selectedAnswer;
        if (!await saveState()) {
          render();
          return;
        }
        render();
        return;
      }
      const score = quiz.questions.reduce((total, question, index) => total + (active.answers[index] === question.answer ? 1 : 0), 0);
      state.mockTestResults.push({ quizId: quiz.id, score, total: quiz.questions.length, completedAt: new Date().toISOString() });
      recordActivity();
      state.activeTest = null;
      if (!await saveState()) {
        render();
        return;
      }
      showToast(`Test complete: ${score} / ${quiz.questions.length}.`);
      render();
      return;
    }
    if (action === "exit-mock-test") {
      if (state.activeTest && !window.confirm("Exit this test? Your unfinished answers will be discarded.")) return;
      state.activeTest = null;
      if (!await saveState()) {
        render();
        return;
      }
      go("mock-test");
      return;
    }
    if (action === "exit-mock-interview") {
      const active = state.mockInterview;
      if (active) {
        const draft = document.getElementById("interview-answer");
        if (draft) {
          if (!Array.isArray(active.answers)) active.answers = [];
          active.answers[active.index] = draft.value;
          if (draft.value.trim()) recordActivity();
        }
        const prompts = interviewPromptsForRole(active.role).slice(0, active.questionCount);
        state.interviewSessions.push({
          role: active.role, format: active.format, completed: false, completedAt: new Date().toISOString(),
          answers: prompts.slice(0, active.index + 1).map((item, index) => ({ prompt: item.prompt, response: (active.answers || [])[index] || "" }))
        });
        state.mockInterview = null;
        if (!await saveState()) {
          render();
          return;
        }
        showToast("Practice notes saved.");
      }
      go("mock-interview");
      return;
    }
    if (action === "download-resume") {
      const resume = state.resume;
      const content = [
        resume.fullName || "Your name", resume.headline || state.profile.goal,
        [resume.location, state.email].filter(Boolean).join(" | "), "",
        "SUMMARY", resume.summary, "", "EDUCATION", resume.education, "",
        "SKILLS", resume.skills, "", "EXPERIENCE", resume.experience, "",
        "PROJECTS / PROOF OF WORK", resume.projects, "", "LINKS", resume.links
      ].join("\r\n");
      downloadFile("pathwise-resume.txt", content, "text/plain;charset=utf-8");
      showToast("Resume download requested. Check your browser downloads.");
      return;
    }
    if (action === "export-data") {
      const exportData = {
        format: "Pathwise local student data",
        exportedAt: new Date().toISOString(),
        student: {
          email: state.email, profile: state.profile, completed: state.completed, enrolled: state.enrolled,
          assessmentMarks: state.assessmentMarks, labMarks: state.labMarks, mockTestResults: state.mockTestResults,
          activeTest: state.activeTest, mockInterview: state.mockInterview,
          practicedQuestions: state.practicedQuestions, interviewSessions: state.interviewSessions,
          resume: state.resume, savedJobs: state.savedJobs, roadmapTasks: state.roadmapTasks,
          activityDays: state.activityDays, progressHistory: state.progressHistory
        }
      };
      downloadFile("pathwise-student-data.json", JSON.stringify(exportData, null, 2), "application/json");
      showToast("Data export requested. Check your browser downloads.");
      return;
    }
    if (action === "clear-learning-data") {
      if (!window.confirm("Clear course progress, streak and chart history, assessments, and practice history? Your profile and resume will remain.")) return;
      state.completed = [];
      state.enrolled = [];
      state.assessmentMarks = {};
      state.labMarks = {};
      state.mockTestResults = [];
      state.activeTest = null;
      state.practicedQuestions = [];
      state.interviewSessions = [];
      state.mockInterview = null;
      state.savedJobs = [];
      state.roadmapTasks = [];
      state.activityDays = [];
      state.progressHistory = [];
      if (!await saveState()) {
        render();
        return;
      }
      showToast("Learning data cleared.");
      render();
      return;
    }
    if (action === "copy-profile") {
      const lines = [
        state.resume.fullName || "Student",
        state.resume.headline || state.profile.goal,
        `${state.profile.branch} · Semester ${state.profile.semester}`,
        state.resume.summary,
        state.resume.projects
      ].filter(Boolean);
      if (!navigator.clipboard || typeof navigator.clipboard.writeText !== "function") {
        showToast("Clipboard access is unavailable in this browser.");
        return;
      }
      navigator.clipboard.writeText(lines.join("\n")).then(
        () => showToast("Profile summary copied."),
        error => {
          console.error("Pathwise could not copy the profile summary.", error);
          showToast("Profile summary could not be copied.");
        }
      );
      return;
    }
    if (action === "details") return go(`course/${encodeURIComponent(code)}`);
    if (!course) return;
    if (action === "enroll") {
      if (!prerequisitesMet(course)) {
        showToast("Prerequisites not met. Enrollment is locked.");
        return;
      }
      if (!state.enrolled.includes(code) && !state.completed.includes(code)) state.enrolled.push(code);
      recordActivity();
      if (!await saveState()) {
        render();
        return;
      }
      showToast(`Enrolled in ${course.code}.`);
    } else if (action === "complete") {
      if (!state.enrolled.includes(code) || !prerequisitesMet(course)) {
        showToast("Enroll in this course after meeting its prerequisites.");
        return;
      }
      state.enrolled = state.enrolled.filter(item => item !== code);
      state.completed.push(code);
      recordActivity();
      recordProgressSnapshot();
      if (!await saveState()) {
        render();
        return;
      }
      showToast(`${course.code} marked complete. New courses may now be available.`);
    }
    render();
  }

  function render() {
    if (!state.email) {
      renderLanding();
      return;
    }
    if (!state.profile) {
      renderOnboarding();
      return;
    }
    const route = getRoute();
    if (route.page === "catalog") catalog();
    else if (route.page === "course") courseDetail(decodeURIComponent(route.code || ""));
    else if (route.page === "profile") profilePage();
    else if (route.page === "edit-profile") editProfilePage();
    else if (route.page === "mock-test") mockTestPage();
    else if (route.page === "interview-prep") interviewPrepPage();
    else if (route.page === "resume") resumePage();
    else if (route.page === "mock-interview") mockInterviewPage();
    else if (route.page === "assessment") assessmentPage();
    else if (route.page === "jobs") jobsPage();
    else if (route.page === "settings") settingsPage();
    else dashboard();
  }

  app.addEventListener("click", event => {
    const target = event.target.closest("[data-action]");
    if (!target) return;
    act(target.dataset.action, target.dataset.code).catch(error => {
      console.error("Pathwise could not complete this action.", error);
      showToast("This action could not be completed.");
    });
  });
  window.addEventListener("hashchange", () => {
    mobileMenuOpen = false;
    render();
  });

  if (!window.location.hash && state.profile) window.location.hash = "/dashboard";
  render();
})();
